"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import type { BrandInfo, StrangerTrip, ServiceCardItem, DmcData, MunnarSpot, InquiryRecord } from "@/lib/types"
import { loadFromStorage, saveToStorage } from "@/lib/storage"
import {
  BRAND_PHONE,
  BRAND_PHONE_DISPLAY,
  BRAND_WHATSAPP,
  BRAND_EMAIL,
  BRAND_LOCATION,
  MUNNAR_IMAGES,
  STRANGER_TRIPS,
  SERVICES_LIST,
  DMC_SERVICES,
  DMC_TARGET_AUDIENCE,
  MUNNAR_SPOTS,
} from "@/lib/travel-data"

const DEFAULT_BRAND_INFO: BrandInfo = {
  name: "UNKNWN",
  tagline: "Travel. People. Stories.",
  conceptTagline: "Come as a stranger, leave as a story.",
  phone: BRAND_PHONE,
  phoneDisplay: BRAND_PHONE_DISPLAY,
  whatsapp: BRAND_WHATSAPP,
  email: BRAND_EMAIL,
  location: BRAND_LOCATION,
  topBannerText: "MUNNAR'S #1 STRANGER TRIPS & LOCAL DESTINATION PARTNER",
  heroHeadlineLine1: "COME AS A",
  heroHeadlineAccent: "STRANGER.",
  heroHeadlineLine2: "LEAVE AS A",
  heroHeadlineEnding: "STORY.",
  heroSubtitle:
    "Curated Munnar trips for people who want to meet new people, explore new places and create unforgettable memories.",
  heroImage: MUNNAR_IMAGES.heroMunnar,
}

const DEFAULT_DMC_DATA: DmcData = {
  badge: "B2B DESTINATION MANAGEMENT COMPANY",
  headline: "YOUR LOCAL DESTINATION",
  highlightWord: "PARTNER IN MUNNAR.",
  subheadline:
    "On-ground execution, wholesale hotel contracting, 4x4 Jeep fleet logistics, and end-to-end ground handling in Munnar, Kerala.",
  description:
    "We are stationed locally in Munnar. Whether you are a retail travel agent, corporate offsite committee, college tour organizer, or premium group planner, UNKNWN DMC operates as your dedicated on-ground execution team with zero friction.",
  phone: BRAND_PHONE,
  email: BRAND_EMAIL,
  officeLocation: BRAND_LOCATION,
  services: DMC_SERVICES,
  targetAudience: DMC_TARGET_AUDIENCE,
}

interface TravelDataContextType {
  brandInfo: BrandInfo
  strangerTrips: StrangerTrip[]
  servicesList: ServiceCardItem[]
  dmcData: DmcData
  munnarSpots: MunnarSpot[]
  inquiries: InquiryRecord[]
  addInquiry: (inquiry: Omit<InquiryRecord, "id" | "dateSubmitted" | "status">) => void
  updateInquiryStatus: (id: string, status: InquiryRecord["status"]) => void
  deleteInquiry: (id: string) => void
  updateBrandInfo: (info: BrandInfo) => void
  updateStrangerTrip: (trip: StrangerTrip) => void
  addStrangerTrip: (trip: StrangerTrip) => void
  deleteStrangerTrip: (id: string) => void
  updateServiceItem: (item: ServiceCardItem) => void
  addServiceItem: (item: ServiceCardItem) => void
  deleteServiceItem: (id: string) => void
  updateDmcData: (data: DmcData) => void
  updateMunnarSpot: (index: number, spot: MunnarSpot) => void
  addMunnarSpot: (spot: MunnarSpot) => void
  deleteMunnarSpot: (index: number) => void
  resetAllContent: () => void
}

const TravelDataContext = createContext<TravelDataContextType | undefined>(undefined)

export function TravelDataProvider({ children }: { children: ReactNode }) {
  const [brandInfo, setBrandInfo] = useState<BrandInfo>(DEFAULT_BRAND_INFO)
  const [strangerTrips, setStrangerTrips] = useState<StrangerTrip[]>(STRANGER_TRIPS)
  const [servicesList, setServicesList] = useState<ServiceCardItem[]>(SERVICES_LIST)
  const [dmcData, setDmcData] = useState<DmcData>(DEFAULT_DMC_DATA)
  const [munnarSpots, setMunnarSpots] = useState<MunnarSpot[]>(MUNNAR_SPOTS)
  const [inquiries, setInquiries] = useState<InquiryRecord[]>([])
  const [hydrated, setHydrated] = useState(false)

  // Hydrate from localStorage once on mount (client only), falling back to the static defaults.
  useEffect(() => {
    setBrandInfo(loadFromStorage("brandInfo", DEFAULT_BRAND_INFO))
    setStrangerTrips(loadFromStorage("strangerTrips", STRANGER_TRIPS))
    setServicesList(loadFromStorage("servicesList", SERVICES_LIST))
    setDmcData(loadFromStorage("dmcData", DEFAULT_DMC_DATA))
    setMunnarSpots(loadFromStorage("munnarSpots", MUNNAR_SPOTS))
    setInquiries(loadFromStorage("inquiries", [] as InquiryRecord[]))
    setHydrated(true)
  }, [])

  useEffect(() => {
    if (hydrated) saveToStorage("brandInfo", brandInfo)
  }, [brandInfo, hydrated])
  useEffect(() => {
    if (hydrated) saveToStorage("strangerTrips", strangerTrips)
  }, [strangerTrips, hydrated])
  useEffect(() => {
    if (hydrated) saveToStorage("servicesList", servicesList)
  }, [servicesList, hydrated])
  useEffect(() => {
    if (hydrated) saveToStorage("dmcData", dmcData)
  }, [dmcData, hydrated])
  useEffect(() => {
    if (hydrated) saveToStorage("munnarSpots", munnarSpots)
  }, [munnarSpots, hydrated])
  useEffect(() => {
    if (hydrated) saveToStorage("inquiries", inquiries)
  }, [inquiries, hydrated])

  const addInquiry = (inquiry: Omit<InquiryRecord, "id" | "dateSubmitted" | "status">) => {
    const newRecord: InquiryRecord = {
      ...inquiry,
      id: `inq-${Date.now()}`,
      dateSubmitted: new Date().toLocaleString(),
      status: "New",
    }
    setInquiries((prev) => [newRecord, ...prev])
  }

  const updateInquiryStatus = (id: string, status: InquiryRecord["status"]) => {
    setInquiries((prev) => prev.map((inq) => (inq.id === id ? { ...inq, status } : inq)))
  }

  const deleteInquiry = (id: string) => {
    setInquiries((prev) => prev.filter((inq) => inq.id !== id))
  }

  const updateBrandInfo = (info: BrandInfo) => setBrandInfo(info)

  const updateStrangerTrip = (trip: StrangerTrip) => {
    setStrangerTrips((prev) => prev.map((t) => (t.id === trip.id ? trip : t)))
  }

  const addStrangerTrip = (trip: StrangerTrip) => {
    setStrangerTrips((prev) => [...prev, trip])
  }

  const deleteStrangerTrip = (id: string) => {
    setStrangerTrips((prev) => prev.filter((t) => t.id !== id))
  }

  const updateServiceItem = (item: ServiceCardItem) => {
    setServicesList((prev) => prev.map((s) => (s.id === item.id ? item : s)))
  }

  const addServiceItem = (item: ServiceCardItem) => {
    setServicesList((prev) => [...prev, item])
  }

  const deleteServiceItem = (id: string) => {
    setServicesList((prev) => prev.filter((s) => s.id !== id))
  }

  const updateDmcData = (data: DmcData) => setDmcData(data)

  const updateMunnarSpot = (index: number, spot: MunnarSpot) => {
    setMunnarSpots((prev) => prev.map((s, i) => (i === index ? spot : s)))
  }

  const addMunnarSpot = (spot: MunnarSpot) => {
    setMunnarSpots((prev) => [...prev, spot])
  }

  const deleteMunnarSpot = (index: number) => {
    setMunnarSpots((prev) => prev.filter((_, i) => i !== index))
  }

  const resetAllContent = () => {
    setBrandInfo(DEFAULT_BRAND_INFO)
    setStrangerTrips(STRANGER_TRIPS)
    setServicesList(SERVICES_LIST)
    setDmcData(DEFAULT_DMC_DATA)
    setMunnarSpots(MUNNAR_SPOTS)
  }

  return (
    <TravelDataContext.Provider
      value={{
        brandInfo,
        strangerTrips,
        servicesList,
        dmcData,
        munnarSpots,
        inquiries,
        addInquiry,
        updateInquiryStatus,
        deleteInquiry,
        updateBrandInfo,
        updateStrangerTrip,
        addStrangerTrip,
        deleteStrangerTrip,
        updateServiceItem,
        addServiceItem,
        deleteServiceItem,
        updateDmcData,
        updateMunnarSpot,
        addMunnarSpot,
        deleteMunnarSpot,
        resetAllContent,
      }}
    >
      {children}
    </TravelDataContext.Provider>
  )
}

export function useTravelData(): TravelDataContextType {
  const context = useContext(TravelDataContext)
  if (!context) {
    throw new Error("useTravelData must be used within a TravelDataProvider")
  }
  return context
}
