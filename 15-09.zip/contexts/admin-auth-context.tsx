"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"

const SESSION_KEY = "unknwn_admin_session"
const CREDENTIALS_KEY = "unknwn_admin_credentials"

const DEFAULT_EMAIL = "admin@unknwnmunnar.com"
const DEFAULT_PASSWORD = "munnar2024"

interface StoredCredentials {
  email: string
  passwordHash: string
}

/** Simple non-cryptographic hash so the password isn't stored as plain text in localStorage. */
async function hashPassword(password: string): Promise<string> {
  if (typeof window !== "undefined" && window.crypto?.subtle) {
    const bytes = new TextEncoder().encode(password)
    const digest = await window.crypto.subtle.digest("SHA-256", bytes)
    return Array.from(new Uint8Array(digest))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("")
  }
  // Fallback for environments without SubtleCrypto (should not happen in modern browsers).
  let hash = 0
  for (let i = 0; i < password.length; i++) {
    hash = (hash << 5) - hash + password.charCodeAt(i)
    hash |= 0
  }
  return String(hash)
}

function readCredentials(): StoredCredentials | null {
  if (typeof window === "undefined") return null
  try {
    const raw = window.localStorage.getItem(CREDENTIALS_KEY)
    if (!raw) return null
    return JSON.parse(raw) as StoredCredentials
  } catch {
    return null
  }
}

interface AdminAuthContextType {
  isAuthenticated: boolean
  isChecking: boolean
  adminEmail: string
  usingDefaultCredentials: boolean
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  updateCredentials: (params: {
    currentPassword: string
    newEmail: string
    newPassword?: string
  }) => Promise<{ success: boolean; error?: string }>
}

const AdminAuthContext = createContext<AdminAuthContextType | undefined>(undefined)

export function AdminAuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isChecking, setIsChecking] = useState(true)
  const [adminEmail, setAdminEmail] = useState(DEFAULT_EMAIL)
  const [usingDefaultCredentials, setUsingDefaultCredentials] = useState(true)

  useEffect(() => {
    const session = window.localStorage.getItem(SESSION_KEY)
    setIsAuthenticated(session === "true")
    const stored = readCredentials()
    if (stored) {
      setAdminEmail(stored.email)
      setUsingDefaultCredentials(false)
    }
    setIsChecking(false)
  }, [])

  const login = async (email: string, password: string) => {
    const stored = readCredentials()
    const hashedInput = await hashPassword(password)

    const success = stored
      ? email.trim().toLowerCase() === stored.email.toLowerCase() && hashedInput === stored.passwordHash
      : email.trim().toLowerCase() === DEFAULT_EMAIL && password === DEFAULT_PASSWORD

    if (success) {
      window.localStorage.setItem(SESSION_KEY, "true")
      setIsAuthenticated(true)
    }
    return success
  }

  const logout = () => {
    window.localStorage.removeItem(SESSION_KEY)
    setIsAuthenticated(false)
  }

  const updateCredentials = async ({
    currentPassword,
    newEmail,
    newPassword,
  }: {
    currentPassword: string
    newEmail: string
    newPassword?: string
  }) => {
    const stored = readCredentials()
    const currentHash = await hashPassword(currentPassword)
    const isCurrentValid = stored
      ? currentHash === stored.passwordHash
      : currentPassword === DEFAULT_PASSWORD

    if (!isCurrentValid) {
      return { success: false, error: "Current password is incorrect." }
    }

    const trimmedEmail = newEmail.trim().toLowerCase()
    if (!trimmedEmail || !trimmedEmail.includes("@")) {
      return { success: false, error: "Please enter a valid email address." }
    }

    if (newPassword && newPassword.length < 6) {
      return { success: false, error: "New password must be at least 6 characters." }
    }

    const passwordHash = newPassword ? await hashPassword(newPassword) : stored?.passwordHash ?? (await hashPassword(DEFAULT_PASSWORD))

    const next: StoredCredentials = { email: trimmedEmail, passwordHash }
    window.localStorage.setItem(CREDENTIALS_KEY, JSON.stringify(next))
    setAdminEmail(trimmedEmail)
    setUsingDefaultCredentials(false)

    return { success: true }
  }

  return (
    <AdminAuthContext.Provider
      value={{
        isAuthenticated,
        isChecking,
        adminEmail,
        usingDefaultCredentials,
        login,
        logout,
        updateCredentials,
      }}
    >
      {children}
    </AdminAuthContext.Provider>
  )
}

export function useAdminAuth(): AdminAuthContextType {
  const context = useContext(AdminAuthContext)
  if (!context) {
    throw new Error("useAdminAuth must be used within an AdminAuthProvider")
  }
  return context
}

export const ADMIN_LOGIN_HINT = { email: DEFAULT_EMAIL, password: DEFAULT_PASSWORD }
