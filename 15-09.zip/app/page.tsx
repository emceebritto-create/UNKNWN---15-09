"use client"

import { useState } from "react"
import { TravelDataProvider } from "@/contexts/travel-data-context"
import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { StrangerTripsSection } from "@/components/stranger-trips-section"
import { CustomTourSection } from "@/components/custom-tour-section"
import { ServicesSection } from "@/components/services-section"
import { MunnarHighlights } from "@/components/munnar-highlights"
import { DmcSection } from "@/components/dmc-section"
import { ContactSection } from "@/components/contact-section"
import { Footer } from "@/components/footer"
import { BookingModal } from "@/components/booking-modal"

export default function Page() {
  const [activeTab, setActiveTab] = useState("home")
  const [isBookingOpen, setIsBookingOpen] = useState(false)
  const [preSelectedTrip, setPreSelectedTrip] = useState<string | undefined>(undefined)

  const scrollToSection = (id: string) => {
    setActiveTab(id)
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" })
  }

  const openBooking = (tripTitle?: string) => {
    setPreSelectedTrip(tripTitle)
    setIsBookingOpen(true)
  }

  const openCustomTour = () => scrollToSection("custom-tours")

  return (
    <TravelDataProvider>
      <div className="min-h-screen bg-black">
        <Header activeTab={activeTab} setActiveTab={setActiveTab} onOpenBooking={openBooking} onOpenCustomTour={openCustomTour} />

        <Hero onExploreStrangerTrips={() => scrollToSection("stranger-trips")} onPlanNormalTour={openCustomTour} onOpenBooking={() => openBooking()} />

        <StrangerTripsSection onJoinTrip={(title) => openBooking(title)} />

        <CustomTourSection />

        <ServicesSection
          onSelectService={() => scrollToSection("contact")}
          onNavigateStrangerTrips={() => scrollToSection("stranger-trips")}
          onNavigateCustomTours={() => scrollToSection("custom-tours")}
        />

        <MunnarHighlights />

        <DmcSection />

        <ContactSection />

        <Footer onNavigate={scrollToSection} onOpenBooking={() => openBooking()} onOpenCustomTour={openCustomTour} />

        <BookingModal isOpen={isBookingOpen} onClose={() => setIsBookingOpen(false)} preSelectedTrip={preSelectedTrip} />
      </div>
    </TravelDataProvider>
  )
}
