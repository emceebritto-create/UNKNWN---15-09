import type { ReactNode } from "react"
import { AdminAuthProvider } from "@/contexts/admin-auth-context"
import { TravelDataProvider } from "@/contexts/travel-data-context"

export default function AdminLayout({ children }: { children: ReactNode }) {
  return (
    <AdminAuthProvider>
      <TravelDataProvider>{children}</TravelDataProvider>
    </AdminAuthProvider>
  )
}
