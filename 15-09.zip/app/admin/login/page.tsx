"use client"

import { useState, type FormEvent } from "react"
import { useRouter } from "next/navigation"
import { useAdminAuth, ADMIN_LOGIN_HINT } from "@/contexts/admin-auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Lock } from "lucide-react"

function LoginForm() {
  const router = useRouter()
  const { login, usingDefaultCredentials } = useAdminAuth()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    const success = await login(email, password)
    if (success) {
      router.push("/admin")
    } else {
      setError("Invalid email or password. Please try again.")
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-black px-4">
      <div className="w-full max-w-sm rounded-2xl border border-white/10 bg-neutral-950 p-8 shadow-2xl">
        <div className="mb-6 flex flex-col items-center gap-2 text-center">
          <div className="flex size-12 items-center justify-center rounded-full bg-amber-500/10">
            <Lock className="size-5 text-amber-500" aria-hidden="true" />
          </div>
          <h1 className="text-xl font-bold tracking-tight text-white">UNKNWN Admin</h1>
          <p className="text-sm text-neutral-400">Sign in to manage your website content</p>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="email" className="text-neutral-300">
              Email
            </Label>
            <Input
              id="email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="border-white/10 bg-neutral-900 text-white placeholder:text-neutral-500"
              placeholder="admin@unknwnmunnar.com"
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="password" className="text-neutral-300">
              Password
            </Label>
            <Input
              id="password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="border-white/10 bg-neutral-900 text-white placeholder:text-neutral-500"
              placeholder="Enter your password"
            />
          </div>

          {error ? (
            <p role="alert" className="text-sm text-red-400">
              {error}
            </p>
          ) : null}

          <Button type="submit" className="mt-2 bg-amber-500 text-black hover:bg-amber-400">
            Sign In
          </Button>
        </form>

        {usingDefaultCredentials ? (
          <p className="mt-6 text-center text-xs text-neutral-500">
            Demo credentials — {ADMIN_LOGIN_HINT.email} / {ADMIN_LOGIN_HINT.password}
          </p>
        ) : null}
      </div>
    </main>
  )
}

export default function AdminLoginPage() {
  return <LoginForm />
}
