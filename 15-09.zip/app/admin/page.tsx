"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useAdminAuth } from "@/contexts/admin-auth-context"
import { useTravelData } from "@/contexts/travel-data-context"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { BrandEditor } from "@/components/admin/brand-editor"
import { ServicesEditor } from "@/components/admin/services-editor"
import { MunnarSpotsEditor } from "@/components/admin/munnar-spots-editor"
import { DmcEditor } from "@/components/admin/dmc-editor"
import { StrangerTripsEditor } from "@/components/admin/stranger-trips-editor"
import { InquiriesPanel } from "@/components/admin/inquiries-panel"
import { SecuritySettings } from "@/components/admin/security-settings"
import {
  LayoutDashboard,
  Sparkles,
  MapPinned,
  Wrench,
  Building2,
  Compass,
  Inbox,
  LogOut,
  ExternalLink,
  ShieldCheck,
} from "lucide-react"
import { cn } from "@/lib/utils"

type AdminTab = "overview" | "brand" | "trips" | "services" | "spots" | "dmc" | "inquiries" | "security"

const NAV_ITEMS: { id: AdminTab; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "brand", label: "Brand & Hero", icon: Sparkles },
  { id: "trips", label: "Stranger Trips", icon: Compass },
  { id: "services", label: "Services", icon: Wrench },
  { id: "spots", label: "Munnar Highlights", icon: MapPinned },
  { id: "dmc", label: "DMC Section", icon: Building2 },
  { id: "inquiries", label: "Inquiries", icon: Inbox },
  { id: "security", label: "Security", icon: ShieldCheck },
]

export default function AdminDashboardPage() {
  const router = useRouter()
  const { isAuthenticated, isChecking, logout } = useAdminAuth()
  const { strangerTrips, servicesList, munnarSpots, inquiries } = useTravelData()
  const [activeTab, setActiveTab] = useState<AdminTab>("overview")

  useEffect(() => {
    if (!isChecking && !isAuthenticated) {
      router.replace("/admin/login")
    }
  }, [isChecking, isAuthenticated, router])

  if (isChecking || !isAuthenticated) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-black">
        <p className="text-sm text-neutral-500">Checking session…</p>
      </main>
    )
  }

  const newInquiryCount = inquiries.filter((i) => i.status === "New").length

  return (
    <div className="flex min-h-screen bg-black text-white">
      <aside className="hidden w-64 shrink-0 flex-col border-r border-white/10 bg-neutral-950 md:flex">
        <div className="flex items-center gap-2 border-b border-white/10 px-6 py-5">
          <span className="text-lg font-bold tracking-tight text-amber-500">UNKNWN</span>
          <span className="text-xs text-neutral-500">Admin</span>
        </div>

        <nav className="flex-1 space-y-1 px-3 py-4">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon
            const isActive = activeTab === item.id
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium transition-colors",
                  isActive ? "bg-amber-500 text-black" : "text-neutral-300 hover:bg-white/5 hover:text-white",
                )}
              >
                <Icon className="size-4 shrink-0" aria-hidden="true" />
                <span className="flex-1">{item.label}</span>
                {item.id === "inquiries" && newInquiryCount > 0 ? (
                  <Badge className="bg-red-500 text-white hover:bg-red-500">{newInquiryCount}</Badge>
                ) : null}
              </button>
            )
          })}
        </nav>

        <div className="flex flex-col gap-2 border-t border-white/10 p-3">
          <Link
            href="/"
            target="_blank"
            className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-neutral-400 hover:bg-white/5 hover:text-white"
          >
            <ExternalLink className="size-4" aria-hidden="true" />
            View live site
          </Link>
          <button
            onClick={() => {
              logout()
              router.replace("/admin/login")
            }}
            className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-neutral-400 hover:bg-white/5 hover:text-red-400"
          >
            <LogOut className="size-4" aria-hidden="true" />
            Sign out
          </button>
        </div>
      </aside>

      <div className="flex flex-1 flex-col overflow-hidden">
        <header className="flex items-center justify-between border-b border-white/10 bg-neutral-950 px-4 py-4 md:px-8">
          <div>
            <h1 className="text-lg font-bold tracking-tight text-white md:text-xl">
              {NAV_ITEMS.find((n) => n.id === activeTab)?.label}
            </h1>
            <p className="text-xs text-neutral-500 md:text-sm">Edits save automatically to this browser</p>
          </div>
          <select
            value={activeTab}
            onChange={(e) => setActiveTab(e.target.value as AdminTab)}
            className="rounded-lg border border-white/10 bg-neutral-900 px-3 py-2 text-sm text-white md:hidden"
            aria-label="Select admin section"
          >
            {NAV_ITEMS.map((item) => (
              <option key={item.id} value={item.id}>
                {item.label}
              </option>
            ))}
          </select>
        </header>

        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          {activeTab === "overview" ? (
            <OverviewPanel
              tripsCount={strangerTrips.length}
              servicesCount={servicesList.length}
              spotsCount={munnarSpots.length}
              inquiriesCount={inquiries.length}
              newInquiryCount={newInquiryCount}
              onNavigate={setActiveTab}
            />
          ) : null}
          {activeTab === "brand" ? <BrandEditor /> : null}
          {activeTab === "trips" ? <StrangerTripsEditor /> : null}
          {activeTab === "services" ? <ServicesEditor /> : null}
          {activeTab === "spots" ? <MunnarSpotsEditor /> : null}
          {activeTab === "dmc" ? <DmcEditor /> : null}
          {activeTab === "inquiries" ? <InquiriesPanel /> : null}
          {activeTab === "security" ? <SecuritySettings /> : null}
        </main>
      </div>
    </div>
  )
}

function OverviewPanel({
  tripsCount,
  servicesCount,
  spotsCount,
  inquiriesCount,
  newInquiryCount,
  onNavigate,
}: {
  tripsCount: number
  servicesCount: number
  spotsCount: number
  inquiriesCount: number
  newInquiryCount: number
  onNavigate: (tab: AdminTab) => void
}) {
  const stats: { label: string; value: number; tab: AdminTab }[] = [
    { label: "Stranger Trips", value: tripsCount, tab: "trips" },
    { label: "Services", value: servicesCount, tab: "services" },
    { label: "Munnar Spots", value: spotsCount, tab: "spots" },
    { label: "Total Inquiries", value: inquiriesCount, tab: "inquiries" },
  ]

  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <button
            key={stat.label}
            onClick={() => onNavigate(stat.tab)}
            className="flex flex-col gap-1 rounded-xl border border-white/10 bg-neutral-950 p-5 text-left transition-colors hover:border-amber-500/40"
          >
            <span className="text-3xl font-bold text-white">{stat.value}</span>
            <span className="text-sm text-neutral-400">{stat.label}</span>
          </button>
        ))}
      </div>

      {newInquiryCount > 0 ? (
        <button
          onClick={() => onNavigate("inquiries")}
          className="flex items-center justify-between rounded-xl border border-amber-500/30 bg-amber-500/10 p-5 text-left"
        >
          <div>
            <p className="font-semibold text-amber-400">
              {newInquiryCount} new {newInquiryCount === 1 ? "inquiry" : "inquiries"} awaiting response
            </p>
            <p className="text-sm text-neutral-400">Review and follow up with customers</p>
          </div>
          <Inbox className="size-5 text-amber-400" aria-hidden="true" />
        </button>
      ) : null}

      <div className="rounded-xl border border-white/10 bg-neutral-950 p-6">
        <h2 className="mb-3 text-base font-semibold text-white">What you can edit here</h2>
        <ul className="grid grid-cols-1 gap-2 text-sm text-neutral-400 sm:grid-cols-2">
          <li>• Brand name, tagline, contact info, hero headline & image</li>
          <li>• Every Stranger Trip — pricing, itinerary, inclusions, photos</li>
          <li>• Services list — scooters, jeeps, cabs, treks, stays, and more</li>
          <li>• Munnar highlight spots — description, category, photo</li>
          <li>• DMC section — services offered and target audience</li>
          <li>• Incoming customer inquiries and their status</li>
        </ul>
        <p className="mt-4 text-xs text-neutral-500">
          Content is currently saved to this browser&apos;s local storage. Connect a database to persist changes across
          devices and browsers.
        </p>
      </div>
    </div>
  )
}
