import type { StrangerTrip, ServiceCardItem, AccommodationType, TransportationType, MunnarExperience, MunnarSpot } from "./types"

export const BRAND_PHONE = "9447673015"
export const BRAND_PHONE_DISPLAY = "+91 94476 73015"
export const BRAND_WHATSAPP = "https://wa.me/919447673015"
export const BRAND_EMAIL = "hello@unknwnmunnar.com"
export const BRAND_LOCATION = "Near Tea Museum, Mattupetty Road, Munnar, Kerala 685612"

export const MUNNAR_IMAGES = {
  heroMunnar: "https://images.unsplash.com/photo-1596401057633-54a8fe8ef647?auto=format&fit=crop&w=1800&q=85",
  teaPlantation: "https://images.unsplash.com/photo-1596401057633-54a8fe8ef647?auto=format&fit=crop&w=1200&q=80",
  teaPlantation2: "https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=1200&q=80",
  boatingMattupetty: "https://images.unsplash.com/photo-1544644181-1484b3fdfc62?auto=format&fit=crop&w=1200&q=80",
  boatingKundala: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80",
  jeepSafari: "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=1200&q=80",
  trekkingMunnar: "https://images.unsplash.com/photo-1551632811-561732d1e306?auto=format&fit=crop&w=1200&q=80",
  cyclingTea: "https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&w=1200&q=80",
  ziplineAdventure: "https://images.unsplash.com/photo-1533587851505-d119e13fa0d7?auto=format&fit=crop&w=1200&q=80",
  waterfallsAttukad: "https://images.unsplash.com/photo-1432405972618-c60b0225b8f9?auto=format&fit=crop&w=1200&q=80",
  campingMunnar: "https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?auto=format&fit=crop&w=1200&q=80",
  cottageResort: "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80",
  scooterRental: "https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=1200&q=80",
  cabsMunnar: "https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?auto=format&fit=crop&w=1200&q=80",
  strangerGroup: "https://images.unsplash.com/photo-1527631746610-bca00a040d60?auto=format&fit=crop&w=1200&q=80",
  dmcCorporate: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=1200&q=80",
}

export const STRANGER_TRIPS: StrangerTrip[] = [
  {
    id: "stranger-batch-1",
    title: "Munnar Cloud Trek & Cliff Camp Batch",
    tagline: "Break the ice over high-altitude campfires and misty tea ridges.",
    dates: "Upcoming Weekend (Fri night – Sun eve)",
    duration: "2 Days / 1 Night",
    startingPrice: 3499,
    originalPrice: 4299,
    pickupLocations: ["Kochi Vyttila Hub", "Aluva Metro Station", "Munnar Town Center"],
    groupSize: "12–14 Travellers (Curated)",
    remainingSlots: 4,
    status: "Filling Fast",
    image: MUNNAR_IMAGES.campingMunnar,
    category: "Weekend Special",
    activities: [
      "Lakshmi Hills sunrise ridge trek",
      "Off-grid cliffside tent camping",
      "Stargazing & acoustic campfire session",
      "Hidden waterfall dipping & stream trails",
      "Curated group icebreakers & sunset storytelling",
    ],
    itinerary: [
      {
        day: "Day 1",
        title: "Kochi to Munnar Mist Ascent & Icebreaker Camp",
        highlights: [
          "Early morning pickup from Kochi/Aluva and scenic mountain ghat climb",
          "Pit-stop at Cheeyappara & Valara waterfalls with traditional Kerala chai",
          "Arrive at private hilltop campsite overlooking Lockhart tea valleys",
          "Sunset icebreaker games with 12 new strangers",
          "Acoustic campfire, barbecue dinner & midnight stories under mountain stars",
        ],
      },
      {
        day: "Day 2",
        title: "Sunrise Cloud Walk, Secret Falls & Storytelling",
        highlights: [
          "5:30 AM mist trek to watch the cloud carpet unveil over Munnar peaks",
          "Fresh plantation breakfast and traditional estate brewed tea",
          "Guided hike to secluded freshwater stream & natural dip",
          "Group photo session in the tea labyrinths",
          "Departure back to Kochi with a new circle of lifelong friends",
        ],
      },
    ],
    included: [
      "Transportation from/to Kochi in comfortable tempo/cab",
      "Hilltop camp accommodation on twin/triple sharing",
      "Dinner, breakfast, and barbecue snacks",
      "Local Munnar trek leader & campfire host",
      "All forest permits and entry passes",
    ],
    notIncluded: ["Personal snacks and extra meals outside itinerary", "Personal riding or adventure sports add-ons"],
  },
  {
    id: "stranger-batch-2",
    title: "Kolukkumalai 4x4 Offroad & High Peak Sunrise",
    tagline: "Highest tea estate in the world with a crew of fellow adrenaline lovers.",
    dates: "Next Friday – Sunday Batch",
    duration: "2 Days / 1 Night",
    startingPrice: 3999,
    originalPrice: 4800,
    pickupLocations: ["Ernakulam South", "Angamaly", "Kothamangalam", "Munnar"],
    groupSize: "10–12 Travellers",
    remainingSlots: 2,
    status: "Few Left",
    image: MUNNAR_IMAGES.jeepSafari,
    category: "Camp & Offroad",
    activities: [
      "Brutal rugged 4x4 Jeep Safari up to Kolukkumalai",
      "360-degree golden sunrise over the sea of clouds",
      "Heritage tea factory walk & orthodox leaf tasting",
      "Mattupetty speedboating challenge",
      "Late night board games & group campfire vibes",
    ],
    itinerary: [
      {
        day: "Day 1",
        title: "The Rough Terrain Ascent to The Clouds",
        highlights: [
          "Gathering at Munnar base camp and team pairing",
          "Board heavy-duty 4x4 jeeps for the legendary Kolukkumalai boulder trail",
          "Arrival at high mountain shelter above 7,130 ft",
          "Sunset viewpoint hike to Lion Rock ridge",
          "Campfire dinner & deep travel conversation",
        ],
      },
      {
        day: "Day 2",
        title: "Golden Cloud Ocean & Tea Factory Heritage",
        highlights: [
          "Witness the viral golden sunrise breaking through Tamil Nadu & Kerala mist",
          "Visit the historic 1930s Kolukkumalai orthodox tea processing factory",
          "Breakfast with mountain wind and aromatic fresh black tea",
          "Mattupetty reservoir stop on descent",
          "Final memories reel shoot & drop-off",
        ],
      },
    ],
    included: [
      "4x4 Heavy Jeep transfers up and down the mountain",
      "Mountain stay with bedrolls / tents",
      "Hot campfire dinner & traditional Kerala breakfast",
      "Factory tour fee and guide assistance",
    ],
    notIncluded: ["Any motorized boating tickets at dam", "Personal riding gear"],
  },
  {
    id: "stranger-batch-3",
    title: "Misty Tea Valley, Cycling & Zipline Expedition",
    tagline: "Pedal through emerald slopes and glide above Munnar canopies.",
    dates: "Bi-Weekly Saturday Special",
    duration: "3 Days / 2 Nights",
    startingPrice: 5499,
    originalPrice: 6500,
    pickupLocations: ["Kochi Airport (COK)", "Aluva Metro", "Munnar Town"],
    groupSize: "14 Travellers",
    remainingSlots: 6,
    status: "Open",
    image: MUNNAR_IMAGES.ziplineAdventure,
    category: "Adventure Trek",
    activities: [
      "Downhill mountain cycling through Lockhart estate roads",
      "Highest valley zipline run across 1,800m cable",
      "Kayaking / pedal boating at Kundala Lake",
      "Attukad water cascade trek",
      "Group cooking challenge & music jam by the fire",
    ],
    itinerary: [
      {
        day: "Day 1",
        title: "Welcome to Munnar Highlands & Icebreaker Jam",
        highlights: [
          "Scenic transfer from Kochi airport/city up to Munnar cottage estate",
          "Welcome lunch and intro circle",
          "Short tea garden trail walk to get acclimatized",
          "Evening acoustic jam and local food discovery",
        ],
      },
      {
        day: "Day 2",
        title: "Pedals, Zipline Adrenaline & Waterfalls",
        highlights: [
          "Morning cycling through misty tea valley winding routes",
          "Zipline experience soaring above the mountain valleys",
          "Hike down to the base of Attukad waterfall",
          "Evening campfire and team games",
        ],
      },
      {
        day: "Day 3",
        title: "Kundala Boating & Fond Farewells",
        highlights: [
          "Peaceful morning pedal boating at Kundala Dam",
          "Souvenir shopping at local Munnar spice market",
          "Farewell lunch with strangers-turned-friends",
        ],
      },
    ],
    included: [
      "All intercity and local transfers",
      "2 nights cottage / boutique stay",
      "Bicycles with helmets and safety car escort",
      "Zipline harness gear & activity ticket",
      "5 meals (2 breakfasts, 2 dinners, 1 barbecue night)",
    ],
    notIncluded: ["Lunches at roadside cafes", "Personal medical insurance"],
  },
]

export const ACCOMMODATION_OPTIONS: AccommodationType[] = [
  "No accommodation required",
  "Budget stay",
  "Standard stay",
  "Premium stay",
  "Resort",
  "Cottage",
  "Homestay",
  "Camping",
]

export const TRANSPORTATION_OPTIONS: TransportationType[] = ["Own vehicle", "Rental scooter", "Cab", "Jeep", "Tempo traveller", "Other transportation"]

export const MUNNAR_EXPERIENCES: { name: MunnarExperience; description: string }[] = [
  { name: "Tea plantation visits", description: "Walk through heritage tea gardens and tea factories" },
  { name: "Boating", description: "Mattupetty Dam & Kundala Lake pedal/speed boating" },
  { name: "Zipline", description: "Soar over Munnar valleys on high-altitude cable lines" },
  { name: "Trekking", description: "Sunrise trails, Lakshmi Hills & Meesapulimala peaks" },
  { name: "Cycling", description: "Scenic estate roads and mountain cycling paths" },
  { name: "Waterfalls", description: "Attukad, Lakkam and Cheeyappara forest cascades" },
  { name: "Sightseeing", description: "Top Station, Eravikulam National Park & Echo Point" },
  { name: "Jeep experiences", description: "Rough terrain 4x4 safari to Kolukkumalai & view points" },
  { name: "Camping", description: "Cliff-edge tent stays, bonfires and stargazing" },
  { name: "Local experiences", description: "Authentic Kerala cuisine, spice markets & tribal culture" },
]

export const SERVICES_LIST: ServiceCardItem[] = [
  {
    id: "scooters",
    title: "RENTAL SCOOTERS",
    subtitle: "Explore Munnar at your own pace",
    description:
      "Well-maintained gearless scooters delivered directly to your hotel or Munnar town base. Perfect for couples and solo travelers navigating winding tea valley roads.",
    image: MUNNAR_IMAGES.scooterRental,
    features: ["Helmet provided", "Unlimited kilometers", "Direct pickup/drop", "24/7 roadside assist"],
    category: "Transport",
  },
  {
    id: "stays",
    title: "STAYS",
    subtitle: "Cottages, resorts, homestays, camping & accommodation",
    description:
      "From tranquil tea-estate cottages and mountain-view luxury resorts to budget traveler homestays and cliffside camping under Munnar stars.",
    image: MUNNAR_IMAGES.cottageResort,
    features: ["Handpicked verified stays", "Misty valley views", "Bonfire spots", "Family & couple friendly"],
    category: "Stay",
  },
  {
    id: "jeeps",
    title: "JEEPS",
    subtitle: "Jeep experiences and local mountain travel",
    description:
      "Rugged 4x4 off-road jeep expeditions to Kolukkumalai, Anayirankal, and inaccessible high-altitude ridges with seasoned mountain drivers.",
    image: MUNNAR_IMAGES.jeepSafari,
    features: ["4x4 off-road specialists", "Sunrise trips", "Hidden viewpoints", "Expert local drivers"],
    category: "Transport",
  },
  {
    id: "cabs",
    title: "CABS",
    subtitle: "Local transportation, transfers and sightseeing",
    description:
      "Comfortable sedans, SUVs, and Innovas for airport pickups from Kochi/Coimbatore, round-trip transfers, and Munnar full-day circuit sightseeing.",
    image: MUNNAR_IMAGES.cabsMunnar,
    features: ["Kochi airport pickup", "Fixed transparent rates", "AC/Non-AC options", "Knowledgeable drivers"],
    category: "Transport",
  },
  {
    id: "trekking",
    title: "TREKKING",
    subtitle: "Mountain trails, nature walks and trekking experiences",
    description:
      "Guided treks across Lakshmi Hills ridge, Chokramudi peak, and misty wilderness trails suited for beginners to seasoned mountain adventurers.",
    image: MUNNAR_IMAGES.trekkingMunnar,
    features: ["Forest permit guidance", "Certified local guide", "Sunrise & sunset slots", "Emergency first-aid"],
    category: "Adventure",
  },
  {
    id: "cycling",
    title: "CYCLING",
    subtitle: "Explore Munnar through scenic cycling routes",
    description:
      "High-grade mountain bikes and geared cycles with support vehicles to cruise through aromatic tea estates, pine forests, and eucalyptus groves.",
    image: MUNNAR_IMAGES.cyclingTea,
    features: ["Geared MTBs & helmets", "Custom trail maps", "Escort support available", "Half-day & full-day"],
    category: "Adventure",
  },
  {
    id: "boating",
    title: "BOATING",
    subtitle: "Boating and lake experiences",
    description:
      "Peaceful speed boating and pedal boating sessions at Mattupetty reservoir and tranquil Kundala lake surrounded by green eucalyptus hills.",
    image: MUNNAR_IMAGES.boatingMattupetty,
    features: ["Mattupetty speedboats", "Kundala Shikara & pedal boats", "Life-jackets included", "Instant booking assist"],
    category: "Adventure",
  },
  {
    id: "zipline",
    title: "ZIPLINE & ADVENTURE",
    subtitle: "Adventure activities and experiences",
    description:
      "Get your heart racing on Kerala's longest mountain ziplines, rope bridges, sky-cycles, and rock adventures nestled in Munnar's hills.",
    image: MUNNAR_IMAGES.ziplineAdventure,
    features: ["Double safety harness", "Aerial valley panorama", "Sky-cycling & high rope", "Trained jump masters"],
    category: "Adventure",
  },
  {
    id: "custom-tours",
    title: "CUSTOM TOURS",
    subtitle: "Build a Munnar trip based on your own preferences",
    description:
      "Tailor-made private journeys for families, honeymooners, and friend circles. Choose your own days, preferred stay style, transport, and handpicked activities.",
    image: MUNNAR_IMAGES.teaPlantation,
    features: ["Fully customized pace", "Private vehicle & stays", "Flexible itineraries", "Direct ground concierge"],
    category: "Custom",
  },
  {
    id: "stranger-trips",
    title: "STRANGER TRIPS",
    subtitle: "Meet new people and explore Munnar together",
    description:
      "Our signature community travel batches. Join 10-14 like-minded solo travelers, explore off-beat spots, bond around campfires, and leave with lifelong friendships.",
    image: MUNNAR_IMAGES.strangerGroup,
    features: ["Vetted solo travelers", "Curated icebreaker host", "Campfires & stargazing", "Unforgettable stories"],
    category: "Stranger",
  },
]

export const DMC_SERVICES = [
  { title: "Customized Itineraries", description: "Precision day-by-day itineraries tailored to client demographics, pace, and themes." },
  { title: "Group & MICE Travel", description: "Large group coordination, university batches, and corporate offsites with zero friction." },
  { title: "Corporate Offsites", description: "Conference setups, team-building obstacle courses, and retreat stays in Munnar hills." },
  { title: "Accommodation Contracting", description: "Direct local B2B rates with premium Munnar resorts, plantation bungalows, and campsites." },
  { title: "Fleet & Transportation", description: "Owned and networked fleet of 4x4 Jeeps, Tempo Travellers, Urbanias, and luxury coaches." },
  { title: "Local Experiences & Permits", description: "Exclusive tea tasting access, Forest Department trekking clearances, and cultural nights." },
  { title: "Travel Agency Support", description: "White-labeled ground handling with 24/7 client concierge under your agency brand." },
  { title: "Destination Coordination", description: "Dedicated on-ground managers stationed across Munnar ensuring flawless execution." },
  { title: "On-Ground Travel Assistance", description: "Real-time contingency management, weather updates, route changes, and medical support." },
  { title: "Private Group & Event Logistics", description: "Destination pre-weddings, creator summits, reunions, and celebration banquet management." },
]

export const DMC_TARGET_AUDIENCE = [
  "Travel Agencies",
  "Tour Operators",
  "Corporate Companies",
  "College Groups",
  "Private Groups",
  "Event Companies",
  "Families",
  "Couples",
  "Travel Creators",
]

export const MUNNAR_SPOTS: MunnarSpot[] = [
  {
    name: "Kolukkumalai Estate",
    description: "The world's highest tea plantation at 7,130 ft, famous for breathtaking cloud sea sunrises.",
    type: "Viewpoint & Tea Heritage",
    image: MUNNAR_IMAGES.jeepSafari,
  },
  {
    name: "Mattupetty Dam & Lake",
    description: "Scenic storage reservoir surrounded by tea gardens and mist, home to wild elephant corridors.",
    type: "Boating & Scenic Lake",
    image: MUNNAR_IMAGES.boatingMattupetty,
  },
  {
    name: "Kundala Lake",
    description: "Tranquil arch-dam lake featuring Kashmiri-style Shikara boats and flowering cherry blossoms.",
    type: "Shikara & Pedal Boating",
    image: MUNNAR_IMAGES.boatingKundala,
  },
  {
    name: "Attukad Waterfalls",
    description: "Dramatic cascade gushing through dense mountain jungle and tea estates between Munnar & Pallivasal.",
    type: "Waterfall & Nature Trek",
    image: MUNNAR_IMAGES.waterfallsAttukad,
  },
  {
    name: "Lakshmi Hills",
    description: "Uninterrupted undulating grass ridges offering 360-degree panorama of Munnar's high range peaks.",
    type: "Sunrise Ridge Hike",
    image: MUNNAR_IMAGES.trekkingMunnar,
  },
  {
    name: "Lockhart Tea Gap",
    description: "Iconic mountain pass offering panoramic aerial views of manicured slopes and mist valleys.",
    type: "Tea Valley & Cycling",
    image: MUNNAR_IMAGES.teaPlantation2,
  },
]
