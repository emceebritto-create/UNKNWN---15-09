export interface StrangerTrip {
  id: string
  title: string
  tagline: string
  dates: string
  duration: string
  startingPrice: number
  originalPrice?: number
  pickupLocations: string[]
  groupSize: string
  remainingSlots: number
  status: "Open" | "Filling Fast" | "Few Left" | "Completed"
  image: string
  category: "Weekend Special" | "Adventure Trek" | "Camp & Offroad" | "Monsoon & Mist"
  activities: string[]
  itinerary: {
    day: string
    title: string
    highlights: string[]
  }[]
  included: string[]
  notIncluded: string[]
}

export type AccommodationType =
  | "No accommodation required"
  | "Budget stay"
  | "Standard stay"
  | "Premium stay"
  | "Resort"
  | "Cottage"
  | "Homestay"
  | "Camping"

export type TransportationType = "Own vehicle" | "Rental scooter" | "Cab" | "Jeep" | "Tempo traveller" | "Other transportation"

export type MunnarExperience =
  | "Tea plantation visits"
  | "Boating"
  | "Zipline"
  | "Trekking"
  | "Cycling"
  | "Waterfalls"
  | "Sightseeing"
  | "Jeep experiences"
  | "Camping"
  | "Local experiences"

export interface ServiceCardItem {
  id: string
  title: string
  subtitle: string
  description: string
  image: string
  features: string[]
  category: "Stranger" | "Custom" | "Transport" | "Adventure" | "Stay"
}

export interface BrandInfo {
  name: string
  tagline: string
  conceptTagline: string
  phone: string
  phoneDisplay: string
  whatsapp: string
  email: string
  location: string
  topBannerText: string
  heroHeadlineLine1: string
  heroHeadlineAccent: string
  heroHeadlineLine2: string
  heroHeadlineEnding: string
  heroSubtitle: string
  heroImage: string
}

export interface MunnarSpot {
  name: string
  description: string
  type: string
  image: string
}

export interface DmcData {
  badge: string
  headline: string
  highlightWord: string
  subheadline: string
  description: string
  phone: string
  email: string
  officeLocation: string
  services: { title: string; description: string }[]
  targetAudience: string[]
}

export interface InquiryRecord {
  id: string
  type: "stranger_trip" | "custom_tour" | "dmc" | "contact" | "service"
  title: string
  customerName: string
  phone: string
  email?: string
  dateSubmitted: string
  preferredDate?: string
  details: Record<string, string | number | string[]>
  status: "New" | "Contacted" | "Confirmed" | "Archived"
}
