"use client"

import { useState } from "react"
import { Sparkles, ArrowRight, Phone, MessageCircle } from "lucide-react"
import { useTravelData } from "@/contexts/travel-data-context"
import type { ServiceCardItem } from "@/lib/types"
import { ScrollFadeSection } from "@/components/scroll-fade-section"

interface ServicesSectionProps {
  onSelectService: (serviceName: string) => void
  onNavigateStrangerTrips: () => void
  onNavigateCustomTours: () => void
}

export function ServicesSection({ onSelectService, onNavigateStrangerTrips, onNavigateCustomTours }: ServicesSectionProps) {
  const { servicesList, brandInfo } = useTravelData()
  const [filter, setFilter] = useState<string>("All")

  const categories = ["All", "Transport", "Adventure", "Stay"]

  const filteredServices =
    filter === "All"
      ? servicesList
      : servicesList.filter((s) => s.category === filter || (filter === "Adventure" && s.category === "Adventure"))

  const handleCardClick = (service: ServiceCardItem) => {
    if (service.id === "stranger-trips") {
      onNavigateStrangerTrips()
    } else if (service.id === "custom-tours") {
      onNavigateCustomTours()
    } else {
      onSelectService(service.title)
    }
  }

  return (
    <ScrollFadeSection>
      <section id="services" className="py-20 sm:py-28 bg-yellow-400 text-black relative border-b-2 border-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-14 gap-6">
            <div className="space-y-3 max-w-3xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-black text-yellow-400 text-xs font-black uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5" />
                <span>SECTION 6 • COMPREHENSIVE GROUND SERVICES</span>
              </div>

              <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black uppercase tracking-tight text-black">
                EXPLORE MUNNAR <br />
                <span>WITH UNKNWN</span>
              </h2>

              <p className="text-base sm:text-lg text-neutral-900 font-bold leading-relaxed">
                Everything you need for an unforgettable Munnar experience. From 4x4 mountain jeeps and scooter rentals to high-altitude trekking, lakeside
                boating, and cozy stays.
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setFilter(cat)}
                  className={`px-4 py-2 rounded text-xs font-black uppercase tracking-wider transition-all border-2 border-black cursor-pointer ${
                    filter === cat ? "bg-black text-yellow-400 shadow-md" : "bg-white text-black hover:bg-neutral-100"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredServices.map((srv) => (
              <div
                key={srv.id}
                className="bg-white rounded-xl border-2 border-black overflow-hidden flex flex-col justify-between hover:shadow-2xl transition-all duration-300 group"
              >
                <div className="relative h-48 overflow-hidden bg-neutral-100 border-b-2 border-black">
                  <img
                    src={srv.image || "/placeholder.svg"}
                    alt={`${srv.title} in Munnar Kerala`}
                    crossOrigin="anonymous"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-2.5 right-2.5">
                    <span className="bg-black text-yellow-400 text-[10px] font-black uppercase px-2 py-0.5 rounded border border-yellow-400/40">
                      {srv.category}
                    </span>
                  </div>
                </div>

                <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                  <div className="space-y-1">
                    <h3 className="text-lg font-black uppercase tracking-tight text-black group-hover:text-yellow-600 transition-colors">{srv.title}</h3>
                    <p className="text-xs font-bold text-neutral-700">{srv.subtitle}</p>
                    <p className="text-xs text-neutral-600 font-medium leading-relaxed pt-1">{srv.description}</p>
                  </div>

                  <div className="space-y-1 pt-1 border-t border-neutral-200">
                    {srv.features.slice(0, 2).map((feat, i) => (
                      <div key={i} className="text-[11px] font-bold text-neutral-800 flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-black shrink-0" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={() => handleCardClick(srv)}
                    className="w-full py-2.5 px-3 bg-black hover:bg-neutral-900 text-yellow-400 font-black text-xs uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer mt-2"
                  >
                    <span>{srv.id === "stranger-trips" ? "View Batches" : srv.id === "custom-tours" ? "Plan Itinerary" : "Explore / Enquire"}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-yellow-400" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-14 bg-black text-white p-6 sm:p-8 rounded-xl border-2 border-black flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="space-y-1 text-center sm:text-left">
              <h4 className="text-xl sm:text-2xl font-black uppercase text-white">Need on-demand scooter, jeep or cab pickup right now in Munnar?</h4>
              <p className="text-xs sm:text-sm text-neutral-300 font-medium">
                Call our local station dispatcher directly at <strong className="text-yellow-400 font-bold">{brandInfo.phoneDisplay}</strong> for immediate
                dispatch anywhere in Munnar town or resort areas.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <a
                href={`tel:${brandInfo.phone}`}
                className="px-6 py-3 bg-yellow-400 hover:bg-yellow-300 text-black font-black text-xs uppercase tracking-wider rounded-lg transition-colors flex items-center gap-2 whitespace-nowrap"
              >
                <Phone className="w-4 h-4" />
                <span>Call Dispatcher</span>
              </a>
              <a
                href={brandInfo.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-3 bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs uppercase tracking-wider rounded-lg transition-colors flex items-center gap-2"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      </section>
    </ScrollFadeSection>
  )
}
