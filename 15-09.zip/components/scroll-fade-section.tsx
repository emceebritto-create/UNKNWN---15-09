"use client"

import { useRef, type ReactNode } from "react"
import { motion, useScroll, useTransform } from "motion/react"

/**
 * Wraps a full-page <section> and smoothly fades + scales it down as it
 * scrolls out of view past the top of the viewport. Entrance stays
 * untouched so content is fully visible on the way in — only the exit
 * (scrolling away) is animated.
 */
export function ScrollFadeSection({ children, className }: { children: ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null)

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  })

  const opacity = useTransform(scrollYProgress, [0, 0.75, 1], [1, 1, 0])
  const scale = useTransform(scrollYProgress, [0, 0.75, 1], [1, 1, 0.92])
  const blur = useTransform(scrollYProgress, [0, 0.75, 1], [0, 0, 6])
  const filter = useTransform(blur, (v) => `blur(${v}px)`)

  return (
    <motion.div ref={ref} className={className} style={{ opacity, scale, filter, willChange: "opacity, transform, filter" }}>
      {children}
    </motion.div>
  )
}
