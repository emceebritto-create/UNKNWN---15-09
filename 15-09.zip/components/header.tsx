"use client"

import { useState, useEffect } from "react"
import { Menu, X, Phone, Compass, Users, Sparkles, Briefcase, MessageCircle, MapPin } from "lucide-react"
import { useTravelData } from "@/contexts/travel-data-context"

interface HeaderProps {
  activeTab: string
  setActiveTab: (tab: string) => void
  onOpenBooking: (tripTitle?: string) => void
  onOpenCustomTour: () => void
}

export function Header({ activeTab, setActiveTab, onOpenBooking, onOpenCustomTour }: HeaderProps) {
  const { brandInfo } = useTravelData()
  const [isScrolled, setIsScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const navItems = [
    { id: "stranger-trips", label: "Stranger Trips", badge: "Popular", icon: Users },
    { id: "custom-tours", label: "Normal Tours", badge: "Private", icon: Compass },
    { id: "services", label: "Experiences", icon: Sparkles },
    { id: "destinations", label: "Munnar Spots", icon: MapPin },
    { id: "dmc", label: "UNKNWN DMC", badge: "B2B", icon: Briefcase },
    { id: "contact", label: "Contact", icon: Phone },
  ]

  const handleNavClick = (id: string) => {
    setActiveTab(id)
    setMobileMenuOpen(false)
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <>
      <div className="bg-yellow-400 text-black px-4 py-1.5 text-xs md:text-sm font-bold flex justify-between items-center z-50 sticky top-0 border-b border-black">
        <div className="flex items-center gap-2 max-w-7xl mx-auto w-full justify-between">
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 bg-black rounded-full animate-pulse" />
            <span className="tracking-wide uppercase font-black text-[11px] sm:text-xs">{brandInfo.topBannerText}</span>
            <span className="hidden md:inline text-black/60 font-black">•</span>
            <span className="hidden md:inline font-extrabold text-black/90">{brandInfo.tagline}</span>
          </div>
          <div className="flex items-center gap-3 sm:gap-4">
            <a href={`tel:${brandInfo.phone}`} className="flex items-center gap-1.5 hover:underline font-extrabold" aria-label="Call UNKNWN travel support">
              <Phone className="w-3.5 h-3.5 text-black fill-current" />
              <span>{brandInfo.phoneDisplay}</span>
            </a>
            <span className="hidden sm:inline text-black/40">|</span>
            <a
              href={brandInfo.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:flex items-center gap-1.5 bg-black text-yellow-400 px-2.5 py-0.5 rounded font-black text-xs hover:bg-neutral-900 transition-colors"
            >
              <MessageCircle className="w-3 h-3" />
              <span>WhatsApp Us</span>
            </a>
          </div>
        </div>
      </div>

      <header
        className={`sticky top-[33px] z-40 w-full transition-all duration-300 ${
          isScrolled ? "bg-black/95 backdrop-blur-md border-b border-neutral-800 shadow-xl" : "bg-black border-b border-neutral-900"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <button onClick={() => handleNavClick("home")} className="flex items-center gap-2 text-left group focus:outline-none" aria-label="UNKNWN Munnar Home">
            <div className="flex flex-col">
              <span className="text-2xl sm:text-3xl font-black tracking-tighter text-white group-hover:text-yellow-400 transition-colors flex items-center gap-1">
                {brandInfo.name}
                <span className="w-2.5 h-2.5 rounded-sm bg-yellow-400 inline-block" />
              </span>
              <span className="text-[10px] uppercase font-black tracking-widest text-yellow-400 -mt-1">{brandInfo.tagline}</span>
            </div>
          </button>

          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navItems.map((item) => {
              const isActive = activeTab === item.id
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`px-3 py-2 rounded-md text-sm font-bold tracking-tight transition-colors relative flex items-center gap-1.5 ${
                    isActive ? "text-yellow-400 bg-neutral-900" : "text-neutral-300 hover:text-white hover:bg-neutral-900/60"
                  }`}
                >
                  <span>{item.label}</span>
                  {item.badge && (
                    <span
                      className={`text-[9px] uppercase font-black px-1.5 py-0.5 rounded ${
                        item.badge === "Popular" ? "bg-yellow-400 text-black" : "bg-neutral-800 text-yellow-400 border border-yellow-400/30"
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              )
            })}
          </nav>

          <div className="hidden sm:flex items-center gap-2.5">
            <button
              onClick={onOpenCustomTour}
              className="px-4 py-2.5 rounded-md text-xs sm:text-sm font-extrabold uppercase tracking-wide border-2 border-white/80 text-white hover:bg-white hover:text-black transition-all duration-200"
            >
              Plan Tour
            </button>
            <button
              onClick={() => onOpenBooking()}
              className="px-4 sm:px-5 py-2.5 rounded-md text-xs sm:text-sm font-black uppercase tracking-wide bg-yellow-400 text-black hover:bg-yellow-300 transition-all duration-200 shadow-md shadow-yellow-400/10 flex items-center gap-1.5"
            >
              <Users className="w-4 h-4 text-black stroke-[2.5]" />
              <span>Join a Trip</span>
            </button>
          </div>

          <div className="flex items-center gap-2 lg:hidden">
            <button onClick={() => onOpenBooking()} className="sm:hidden px-3 py-1.5 rounded text-xs font-black uppercase bg-yellow-400 text-black">
              Join Trip
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-neutral-300 hover:text-white bg-neutral-900 rounded-md"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="lg:hidden bg-neutral-950 border-b border-neutral-800 px-4 pt-3 pb-6 space-y-3">
            <div className="grid grid-cols-2 gap-2 pt-1 pb-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false)
                  onOpenBooking()
                }}
                className="w-full py-3 bg-yellow-400 text-black font-black text-xs uppercase tracking-wider rounded-md text-center flex flex-col items-center justify-center gap-1"
              >
                <Users className="w-4 h-4 text-black" />
                <span>Join a Trip</span>
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false)
                  onOpenCustomTour()
                }}
                className="w-full py-3 bg-white text-black font-black text-xs uppercase tracking-wider rounded-md text-center flex flex-col items-center justify-center gap-1"
              >
                <Compass className="w-4 h-4 text-black" />
                <span>Plan Your Tour</span>
              </button>
            </div>

            <div className="border-t border-neutral-800 pt-2 space-y-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className="w-full flex items-center justify-between px-3 py-2.5 text-left rounded-md text-sm font-bold text-neutral-200 hover:bg-neutral-900 hover:text-yellow-400 transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <item.icon className="w-4 h-4 text-yellow-400" />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-yellow-400 text-black">{item.badge}</span>}
                </button>
              ))}
            </div>

            <div className="border-t border-neutral-800 pt-3 flex flex-col gap-2 text-xs">
              <a href={`tel:${brandInfo.phone}`} className="flex items-center justify-center gap-2 py-2 bg-neutral-900 text-white rounded font-bold">
                <Phone className="w-4 h-4 text-yellow-400" />
                <span>Call Us: {brandInfo.phoneDisplay}</span>
              </a>
              <a
                href={brandInfo.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-2 bg-emerald-600 text-white rounded font-bold"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Chat on WhatsApp</span>
              </a>
            </div>
          </div>
        )}
      </header>
    </>
  )
}
