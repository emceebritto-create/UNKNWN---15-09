"use client"

import { useState } from "react"
import { Phone, Mail, MapPin, MessageCircle, Clock, HelpCircle, ChevronDown, ChevronUp, CheckCircle2, Send } from "lucide-react"
import { useTravelData } from "@/contexts/travel-data-context"
import { ScrollFadeSection } from "@/components/scroll-fade-section"

export function ContactSection() {
  const { brandInfo, addInquiry } = useTravelData()
  const [openFaq, setOpenFaq] = useState<number | null>(0)
  const [contactName, setContactName] = useState("")
  const [contactPhone, setContactPhone] = useState("")
  const [contactCategory, setContactCategory] = useState("Stranger Trips")
  const [contactMsg, setContactMsg] = useState("")
  const [msgSent, setMsgSent] = useState(false)

  const faqs = [
    {
      q: "What exactly is an UNKNWN 'Stranger Trip'?",
      a: "Stranger Trips are our curated community journeys where individuals who do not know each other sign up for a weekend or multi-day Munnar adventure. We curate balanced groups of 10–14 travelers, conduct evening icebreakers by the campfire, and explore offbeat ridges, waterfalls, and cliffside camps together.",
    },
    {
      q: "Is it safe for solo female travellers to join?",
      a: "Yes, 100%! Over 50% of our stranger batch participants are solo female travelers. Every batch is supervised by verified, certified local trip captains, with secure verified stays and safe, trusted transportation.",
    },
    {
      q: "What is the difference between Stranger Trips and Normal Tours?",
      a: "Stranger Trips are fixed-date group batches where you travel with new people. Normal Tours (Custom Tours) are completely private trips built specifically for you, your partner, your family, or your private friend group—where you pick your own dates, vehicle, hotel style, and pace.",
    },
    {
      q: "How does UNKNWN DMC work for travel agencies and corporate groups?",
      a: "UNKNWN DMC is our B2B destination management wing stationed locally in Munnar. We provide wholesale hotel contracting, 4x4 Jeep fleet logistics, conference setups, team-building retreats, and on-ground coordination for travel agents and corporate event managers.",
    },
    {
      q: "Where do pickups happen for Munnar trips?",
      a: "We provide scheduled pickups at Cochin International Airport (COK), Aluva Metro Station, Ernakulam / Vyttila Hub, or directly in Munnar town.",
    },
  ]

  const handleGeneralSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!contactName || !contactPhone) {
      alert("Please provide your name and phone number.")
      return
    }

    addInquiry({
      type: "contact",
      title: `General Message: ${contactCategory}`,
      customerName: contactName,
      phone: contactPhone,
      details: {
        category: contactCategory,
        message: contactMsg || "General contact request",
        contactTime: new Date().toLocaleString(),
      },
    })

    setMsgSent(true)
  }

  return (
    <ScrollFadeSection>
      <section id="contact" className="py-20 sm:py-28 bg-white text-black relative border-b-2 border-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-black text-yellow-400 text-xs font-black uppercase tracking-wider">
              <Phone className="w-3.5 h-3.5" />
              <span>CONTACT {brandInfo.name}</span>
            </div>

            <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black uppercase tracking-tight text-black">
              TALK TO OUR <span className="bg-yellow-400 px-2 py-0.5 inline-block">LOCAL TEAM</span>
            </h2>

            <p className="text-base sm:text-lg text-neutral-700 font-semibold leading-relaxed">
              Have questions about upcoming stranger batches, private custom tours, or B2B DMC operations in Munnar? We are just a phone call or WhatsApp
              away.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-16">
            <div className="bg-neutral-50 p-6 sm:p-8 rounded-2xl border-2 border-black shadow-lg flex flex-col justify-between space-y-4 hover:border-yellow-500 transition-colors">
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-xl bg-yellow-400 text-black flex items-center justify-center border-2 border-black">
                  <Phone className="w-6 h-6 stroke-[2.5]" />
                </div>
                <h3 className="text-lg font-black uppercase tracking-tight text-black">Call Our Helpline</h3>
                <p className="text-xs text-neutral-600 font-medium">
                  Direct on-ground assistance for booking queries, emergency dispatch, and vehicle coordination.
                </p>
                <div className="text-2xl font-black text-black tracking-tight">{brandInfo.phoneDisplay}</div>
              </div>
              <a
                href={`tel:${brandInfo.phone}`}
                className="w-full py-3 bg-black hover:bg-neutral-900 text-yellow-400 font-black text-xs uppercase tracking-wider rounded-lg text-center transition-colors flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4" />
                <span>Call {brandInfo.phoneDisplay}</span>
              </a>
            </div>

            <div className="bg-neutral-50 p-6 sm:p-8 rounded-2xl border-2 border-black shadow-lg flex flex-col justify-between space-y-4 hover:border-yellow-500 transition-colors">
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-xl bg-emerald-500 text-white flex items-center justify-center border-2 border-black">
                  <MessageCircle className="w-6 h-6 stroke-[2.5]" />
                </div>
                <h3 className="text-lg font-black uppercase tracking-tight text-black">Instant WhatsApp Chat</h3>
                <p className="text-xs text-neutral-600 font-medium">
                  Get immediate itinerary PDFs, batch schedules, stay photos, and vehicle quotes via WhatsApp.
                </p>
                <div className="text-sm font-bold text-neutral-800">
                  Number: <span className="font-extrabold text-black">{brandInfo.phoneDisplay}</span>
                </div>
              </div>
              <a
                href={brandInfo.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs uppercase tracking-wider rounded-lg text-center transition-colors flex items-center justify-center gap-2 shadow-md"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Open WhatsApp Chat</span>
              </a>
            </div>

            <div className="bg-neutral-50 p-6 sm:p-8 rounded-2xl border-2 border-black shadow-lg flex flex-col justify-between space-y-4 hover:border-yellow-500 transition-colors">
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-xl bg-black text-yellow-400 flex items-center justify-center border-2 border-black">
                  <MapPin className="w-6 h-6 stroke-[2.5]" />
                </div>
                <h3 className="text-lg font-black uppercase tracking-tight text-black">Munnar Base Office</h3>
                <p className="text-xs text-neutral-600 font-medium leading-relaxed">{brandInfo.location}</p>
                <div className="text-xs font-bold text-neutral-700 space-y-1">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-black" />
                    <span>Operations: 6:00 AM – 10:30 PM (Daily)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-black" />
                    <span>{brandInfo.email}</span>
                  </div>
                </div>
              </div>
              <div className="text-[11px] font-black uppercase text-center py-2 bg-yellow-400 text-black rounded border border-black">
                Kerala State Licensed Travel Concierge
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-7 space-y-4">
              <h3 className="text-xl sm:text-2xl font-black uppercase tracking-tight text-black flex items-center gap-2 mb-4">
                <HelpCircle className="w-5 h-5 text-black" />
                <span>Frequently Asked Questions</span>
              </h3>

              <div className="space-y-3">
                {faqs.map((faq, idx) => {
                  const isOpen = openFaq === idx
                  return (
                    <div key={idx} className="border-2 border-black rounded-xl overflow-hidden bg-neutral-50 transition-all">
                      <button
                        onClick={() => setOpenFaq(isOpen ? null : idx)}
                        className="w-full p-4 sm:p-5 text-left font-black text-sm uppercase tracking-tight flex items-center justify-between gap-4 hover:bg-neutral-100 transition-colors"
                      >
                        <span className="text-black">{faq.q}</span>
                        {isOpen ? <ChevronUp className="w-5 h-5 text-black shrink-0" /> : <ChevronDown className="w-5 h-5 text-neutral-600 shrink-0" />}
                      </button>
                      {isOpen && (
                        <div className="px-4 pb-5 pt-1 text-xs sm:text-sm text-neutral-700 font-medium leading-relaxed border-t border-neutral-200">{faq.a}</div>
                      )}
                    </div>
                  )
                })}
              </div>
            </div>

            <div className="lg:col-span-5 bg-black text-white p-6 sm:p-8 rounded-2xl border-2 border-black shadow-xl">
              {msgSent ? (
                <div className="py-12 text-center space-y-4">
                  <div className="w-14 h-14 bg-yellow-400 text-black rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-7 h-7 stroke-[2.5]" />
                  </div>
                  <h4 className="text-xl font-black uppercase text-white">Message Sent!</h4>
                  <p className="text-xs text-neutral-300">
                    Thank you, {contactName}. We have received your query and will reply via phone ({contactPhone}) or WhatsApp promptly.
                  </p>
                  <button onClick={() => setMsgSent(false)} className="px-4 py-2 bg-neutral-800 text-white text-xs font-bold uppercase rounded">
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleGeneralSubmit} className="space-y-4">
                  <div className="space-y-1">
                    <span className="text-[10px] font-black uppercase tracking-widest bg-yellow-400 text-black px-2 py-0.5 rounded">QUICK ASSISTANCE</span>
                    <h4 className="text-xl font-black uppercase text-white mt-1">Send a Direct Message</h4>
                    <p className="text-xs text-neutral-400">Our on-ground Munnar team answers within 30 minutes.</p>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold uppercase text-neutral-300 mb-1">Your Name *</label>
                    <input
                      type="text"
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                      placeholder="e.g. Priyanshu Das"
                      className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold uppercase text-neutral-300 mb-1">Phone Number (WhatsApp) *</label>
                    <input
                      type="tel"
                      value={contactPhone}
                      onChange={(e) => setContactPhone(e.target.value)}
                      placeholder="e.g. 9876543210"
                      className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold uppercase text-neutral-300 mb-1">Area of Interest</label>
                    <select
                      value={contactCategory}
                      onChange={(e) => setContactCategory(e.target.value)}
                      className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                    >
                      <option value="Stranger Trips">AREA 1: Stranger Trips</option>
                      <option value="Normal Tours">AREA 2: Normal / Custom Tours</option>
                      <option value="UNKNWN DMC">AREA 3: UNKNWN DMC (B2B)</option>
                      <option value="Vehicle & Stays">Scooter / Jeep / Stay Rental</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold uppercase text-neutral-300 mb-1">Your Message / Question</label>
                    <textarea
                      rows={3}
                      value={contactMsg}
                      onChange={(e) => setContactMsg(e.target.value)}
                      placeholder="Ask about dates, prices, custom route options..."
                      className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded text-sm text-white font-medium focus:outline-none focus:border-yellow-400"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-yellow-400 hover:bg-yellow-300 text-black font-black text-xs uppercase tracking-wider rounded transition-colors flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5 text-black" />
                    <span>Send Message</span>
                  </button>

                  <div className="text-[11px] text-neutral-400 text-center">
                    Or call directly at <strong className="text-yellow-400">{brandInfo.phoneDisplay}</strong>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </ScrollFadeSection>
  )
}
