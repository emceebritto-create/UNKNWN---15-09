"use client"

import { MapPin, Mountain } from "lucide-react"
import { useTravelData } from "@/contexts/travel-data-context"
import { ScrollFadeSection } from "@/components/scroll-fade-section"

export function MunnarHighlights() {
  const { munnarSpots } = useTravelData()

  return (
    <ScrollFadeSection>
      <section id="destinations" className="py-20 sm:py-28 bg-black text-white relative border-b border-neutral-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-yellow-400 text-black text-xs font-black uppercase tracking-wider">
              <Mountain className="w-3.5 h-3.5" />
              <span>MUNNAR GEOGRAPHY & EXPERIENCES</span>
            </div>

            <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black uppercase tracking-tight text-white">
              EXPLORE ICONIC <span className="text-yellow-400">MUNNAR LOCATIONS</span>
            </h2>

            <p className="text-base sm:text-lg text-neutral-300 font-semibold leading-relaxed">
              Every itinerary and stranger batch we run touches authentic, high-altitude Western Ghats heritage in Munnar, Kerala.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {munnarSpots.map((spot, idx) => (
              <div
                key={idx}
                className="bg-neutral-900 rounded-xl border border-neutral-800 hover:border-yellow-400 overflow-hidden transition-all duration-300 group flex flex-col justify-between"
              >
                <div className="relative h-56 overflow-hidden bg-neutral-950">
                  <img
                    src={spot.image || "/placeholder.svg"}
                    alt={`${spot.name} in Munnar Kerala`}
                    crossOrigin="anonymous"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-transparent to-transparent" />
                  <div className="absolute top-3 left-3 bg-black/80 backdrop-blur-sm text-yellow-400 text-[10px] font-black uppercase px-2.5 py-1 rounded border border-neutral-700 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-yellow-400" />
                    <span>{spot.type}</span>
                  </div>
                </div>

                <div className="p-5 flex-1 flex flex-col justify-between space-y-2">
                  <h3 className="text-xl font-black uppercase tracking-tight text-white group-hover:text-yellow-400 transition-colors">{spot.name}</h3>
                  <p className="text-xs text-neutral-400 font-medium leading-relaxed">{spot.description}</p>

                  <div className="pt-3 border-t border-neutral-800/80 flex items-center justify-between text-[11px] font-bold text-neutral-300">
                    <span className="text-yellow-400">Included in UNKNWN Tours</span>
                    <span className="text-neutral-400">Kerala, 685612</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </ScrollFadeSection>
  )
}
