"use client"

import { useState } from "react"
import { Users, Calendar, Clock, MapPin, Check, ChevronRight, X, Phone, MessageCircle, Flame, Shield, Compass } from "lucide-react"
import { useTravelData } from "@/contexts/travel-data-context"
import type { StrangerTrip } from "@/lib/types"
import { ScrollFadeSection } from "@/components/scroll-fade-section"

interface StrangerTripsSectionProps {
  onJoinTrip: (tripTitle: string) => void
}

export function StrangerTripsSection({ onJoinTrip }: StrangerTripsSectionProps) {
  const { strangerTrips, brandInfo } = useTravelData()
  const [selectedTripModal, setSelectedTripModal] = useState<StrangerTrip | null>(null)
  const [activeCategory, setActiveCategory] = useState<string>("All")

  const categories = ["All", "Weekend Special", "Camp & Offroad", "Adventure Trek"]

  const filteredTrips = activeCategory === "All" ? strangerTrips : strangerTrips.filter((t) => t.category === activeCategory)

  return (
    <ScrollFadeSection>
      <section id="stranger-trips" className="py-20 sm:py-28 bg-black text-white relative border-b border-neutral-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div className="space-y-3 max-w-3xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-yellow-400 text-black text-xs font-black uppercase tracking-wider">
                <Users className="w-3.5 h-3.5" />
                <span>AREA 1 • CORE UNKNWN CONCEPT</span>
              </div>

              <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black uppercase tracking-tight text-white">
                STRANGER TRIPS <br />
                <span className="text-yellow-400">COME AS A STRANGER. LEAVE AS A STORY.</span>
              </h2>

              <p className="text-neutral-300 text-base sm:text-lg font-medium leading-relaxed">
                Our signature Munnar experience. People who don&apos;t know each other join curated group trips, meet new people, explore hidden mountain
                ridges, bond around high-altitude campfires, and forge unforgettable friendships.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-4 py-2 rounded text-xs font-black uppercase tracking-wider transition-all ${
                    activeCategory === cat ? "bg-yellow-400 text-black shadow-md" : "bg-neutral-900 text-neutral-300 hover:bg-neutral-800 border border-neutral-800"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-14">
            <div className="bg-neutral-950 p-5 rounded-lg border border-neutral-800 hover:border-yellow-400/50 transition-colors">
              <div className="w-10 h-10 rounded bg-yellow-400 text-black flex items-center justify-center font-black mb-3">
                <Users className="w-5 h-5" />
              </div>
              <h3 className="font-black text-base uppercase text-white">Curated Group Dynamics</h3>
              <p className="text-xs text-neutral-400 mt-1 font-medium leading-relaxed">
                Balanced 10–14 solo travellers and pairs. No awkward silos, only genuine campfire conversations.
              </p>
            </div>

            <div className="bg-neutral-950 p-5 rounded-lg border border-neutral-800 hover:border-yellow-400/50 transition-colors">
              <div className="w-10 h-10 rounded bg-yellow-400 text-black flex items-center justify-center font-black mb-3">
                <MapPin className="w-5 h-5" />
              </div>
              <h3 className="font-black text-base uppercase text-white">Easy Kochi Pickups</h3>
              <p className="text-xs text-neutral-400 mt-1 font-medium leading-relaxed">
                Pickups at Kochi Airport (COK), Aluva Metro, and Munnar town for hassle-free transit.
              </p>
            </div>

            <div className="bg-neutral-950 p-5 rounded-lg border border-neutral-800 hover:border-yellow-400/50 transition-colors">
              <div className="w-10 h-10 rounded bg-yellow-400 text-black flex items-center justify-center font-black mb-3">
                <Flame className="w-5 h-5" />
              </div>
              <h3 className="font-black text-base uppercase text-white">Offbeat Munnar Spots</h3>
              <p className="text-xs text-neutral-400 mt-1 font-medium leading-relaxed">
                Private cliff campsites, Kolukkumalai sunrise ridges, hidden waterfalls and tea labyrinths.
              </p>
            </div>

            <div className="bg-neutral-950 p-5 rounded-lg border border-neutral-800 hover:border-yellow-400/50 transition-colors">
              <div className="w-10 h-10 rounded bg-yellow-400 text-black flex items-center justify-center font-black mb-3">
                <Shield className="w-5 h-5" />
              </div>
              <h3 className="font-black text-base uppercase text-white">Verified Trip Captains</h3>
              <p className="text-xs text-neutral-400 mt-1 font-medium leading-relaxed">
                Experienced local trek leaders and on-ground hosts keeping everyone safe and connected.
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredTrips.map((trip) => (
              <div
                key={trip.id}
                className="bg-neutral-900 rounded-xl overflow-hidden border-2 border-neutral-800 hover:border-yellow-400 transition-all duration-300 flex flex-col group shadow-xl"
              >
                <div className="relative h-60 overflow-hidden bg-neutral-950">
                  <img
                    src={trip.image || "/placeholder.svg"}
                    alt={trip.title}
                    crossOrigin="anonymous"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-transparent to-transparent" />

                  <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                    <span className="px-2.5 py-1 rounded text-[11px] font-black uppercase tracking-wider bg-yellow-400 text-black">{trip.category}</span>
                    <span
                      className={`px-2.5 py-1 rounded text-[11px] font-black uppercase tracking-wider ${
                        trip.status === "Few Left" ? "bg-rose-500 text-white animate-pulse" : "bg-black/80 text-white backdrop-blur-md border border-neutral-700"
                      }`}
                    >
                      {trip.status}
                    </span>
                  </div>

                  <div className="absolute bottom-3 right-3 text-right bg-black/90 backdrop-blur-md px-3 py-1.5 rounded-lg border border-neutral-700">
                    <div className="text-[10px] uppercase font-bold text-neutral-400">Starting From</div>
                    <div className="flex items-baseline gap-1.5">
                      {trip.originalPrice && <span className="text-xs text-neutral-400 line-through font-bold">₹{trip.originalPrice}</span>}
                      <span className="text-xl font-black text-yellow-400">₹{trip.startingPrice}</span>
                    </div>
                  </div>
                </div>

                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <h3 className="text-xl sm:text-2xl font-black uppercase tracking-tight text-white group-hover:text-yellow-400 transition-colors">
                      {trip.title}
                    </h3>
                    <p className="text-xs text-neutral-300 font-medium italic">&quot;{trip.tagline}&quot;</p>
                  </div>

                  <div className="space-y-2 text-xs border-y border-neutral-800 py-3 text-neutral-300 font-semibold">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-yellow-400 shrink-0" />
                      <span className="font-bold text-white">Dates:</span>
                      <span>{trip.dates}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-yellow-400 shrink-0" />
                      <span className="font-bold text-white">Duration:</span>
                      <span>{trip.duration}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-yellow-400 shrink-0" />
                      <span className="font-bold text-white">Group Size:</span>
                      <span>
                        {trip.groupSize} ({trip.remainingSlots} slots open)
                      </span>
                    </div>
                    <div className="flex items-start gap-2">
                      <MapPin className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
                      <span className="font-bold text-white">Pickup:</span>
                      <span className="text-neutral-300">{trip.pickupLocations.join(", ")}</span>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <span className="text-[11px] font-black uppercase tracking-wider text-yellow-400 block">Experiences & Activities:</span>
                    <ul className="space-y-1">
                      {trip.activities.slice(0, 3).map((act, i) => (
                        <li key={i} className="text-xs text-neutral-300 flex items-start gap-1.5">
                          <Check className="w-3.5 h-3.5 text-yellow-400 shrink-0 mt-0.5" />
                          <span>{act}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-2 grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setSelectedTripModal(trip)}
                      className="py-3 px-3 bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs uppercase tracking-wider rounded text-center transition-colors cursor-pointer"
                    >
                      Trip Details
                    </button>
                    <button
                      onClick={() => onJoinTrip(trip.title)}
                      className="py-3 px-3 bg-yellow-400 hover:bg-yellow-300 text-black font-black text-xs uppercase tracking-wider rounded text-center transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <span>Join Trip</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-14 bg-yellow-400 text-black p-6 sm:p-8 rounded-xl flex flex-col lg:flex-row items-center justify-between gap-6 border-2 border-black">
            <div className="space-y-2 text-center lg:text-left">
              <span className="text-xs font-black uppercase tracking-widest bg-black text-yellow-400 px-2.5 py-1 rounded inline-block">
                NEED CUSTOM DATES OR SOLO INQUIRY?
              </span>
              <h3 className="text-2xl sm:text-3xl font-black uppercase tracking-tight">Have questions about coming solo to a stranger trip?</h3>
              <p className="text-sm font-semibold max-w-2xl text-neutral-900">
                80% of our travellers sign up completely alone. Call our trip coordinators directly at{" "}
                <strong className="underline font-black">{brandInfo.phoneDisplay}</strong> or chat on WhatsApp.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
              <a
                href={`tel:${brandInfo.phone}`}
                className="px-6 py-3.5 rounded bg-black text-yellow-400 font-black text-xs uppercase tracking-wider hover:bg-neutral-900 transition-colors flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4" />
                <span>Call: {brandInfo.phoneDisplay}</span>
              </a>
              <a
                href={brandInfo.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3.5 rounded bg-white text-black font-black text-xs uppercase tracking-wider hover:bg-neutral-100 transition-colors flex items-center justify-center gap-2 border border-black"
              >
                <MessageCircle className="w-4 h-4 text-emerald-600" />
                <span>WhatsApp Us</span>
              </a>
            </div>
          </div>
        </div>

        {selectedTripModal && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
            <div className="bg-neutral-950 border-2 border-yellow-400 text-white rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
              <div className="relative h-64 sm:h-72">
                <img
                  src={selectedTripModal.image || "/placeholder.svg"}
                  alt={selectedTripModal.title}
                  crossOrigin="anonymous"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/40 to-transparent" />
                <button
                  onClick={() => setSelectedTripModal(null)}
                  className="absolute top-4 right-4 bg-black/80 text-white p-2 rounded-full hover:bg-yellow-400 hover:text-black transition-colors"
                  aria-label="Close trip details"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="absolute bottom-4 left-6 right-6 flex justify-between items-end">
                  <div>
                    <span className="bg-yellow-400 text-black px-2.5 py-1 rounded text-xs font-black uppercase tracking-wider">
                      {selectedTripModal.category}
                    </span>
                    <h3 className="text-2xl sm:text-3xl font-black uppercase text-white mt-2">{selectedTripModal.title}</h3>
                    <p className="text-xs text-neutral-300 font-semibold mt-1">
                      {selectedTripModal.dates} • {selectedTripModal.duration}
                    </p>
                  </div>

                  <div className="text-right">
                    <div className="text-xs text-neutral-400 uppercase font-bold">Starting Price</div>
                    <div className="text-2xl sm:text-3xl font-black text-yellow-400">₹{selectedTripModal.startingPrice}</div>
                  </div>
                </div>
              </div>

              <div className="p-6 sm:p-8 space-y-6">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-neutral-900 p-4 rounded-lg text-center border border-neutral-800">
                  <div>
                    <div className="text-[10px] uppercase font-bold text-neutral-400">Duration</div>
                    <div className="text-sm font-black text-white">{selectedTripModal.duration}</div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase font-bold text-neutral-400">Group Batch</div>
                    <div className="text-sm font-black text-white">{selectedTripModal.groupSize}</div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase font-bold text-neutral-400">Slots Open</div>
                    <div className="text-sm font-black text-yellow-400">{selectedTripModal.remainingSlots} Remaining</div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase font-bold text-neutral-400">Pickups</div>
                    <div className="text-sm font-black text-white">Kochi / Munnar</div>
                  </div>
                </div>

                <div>
                  <h4 className="text-lg font-black uppercase tracking-tight text-yellow-400 mb-3 flex items-center gap-2">
                    <Compass className="w-5 h-5" />
                    <span>Day-by-Day Journey</span>
                  </h4>
                  <div className="space-y-4">
                    {selectedTripModal.itinerary.map((day, idx) => (
                      <div key={idx} className="bg-neutral-900/70 p-4 rounded-lg border border-neutral-800">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="px-2 py-0.5 rounded bg-yellow-400 text-black font-black text-xs uppercase">{day.day}</span>
                          <span className="font-extrabold text-sm uppercase text-white">{day.title}</span>
                        </div>
                        <ul className="space-y-1.5 pl-2 border-l-2 border-neutral-700 ml-2 mt-2">
                          {day.highlights.map((h, i) => (
                            <li key={i} className="text-xs text-neutral-300 pl-2">
                              • {h}
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="bg-neutral-900 p-4 rounded-lg border border-neutral-800">
                    <h4 className="font-black text-xs uppercase text-emerald-400 tracking-wider mb-2">What&apos;s Included</h4>
                    <ul className="space-y-1.5 text-xs text-neutral-300">
                      {selectedTripModal.included.map((inc, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{inc}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-neutral-900 p-4 rounded-lg border border-neutral-800">
                    <h4 className="font-black text-xs uppercase text-rose-400 tracking-wider mb-2">Not Included</h4>
                    <ul className="space-y-1.5 text-xs text-neutral-300">
                      {selectedTripModal.notIncluded.map((exc, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-rose-400 font-bold shrink-0">✕</span>
                          <span>{exc}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 pt-2">
                  <button
                    onClick={() => {
                      const title = selectedTripModal.title
                      setSelectedTripModal(null)
                      onJoinTrip(title)
                    }}
                    className="flex-1 py-4 bg-yellow-400 hover:bg-yellow-300 text-black font-black text-sm uppercase tracking-wider rounded-lg transition-colors text-center flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Users className="w-4 h-4" />
                    <span>Book / Enquire for This Trip</span>
                  </button>
                  <a
                    href={`tel:${brandInfo.phone}`}
                    className="py-4 px-6 bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs uppercase tracking-wider rounded-lg text-center flex items-center justify-center gap-2"
                  >
                    <Phone className="w-4 h-4 text-yellow-400" />
                    <span>Call {brandInfo.phoneDisplay}</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}
      </section>
    </ScrollFadeSection>
  )
}
