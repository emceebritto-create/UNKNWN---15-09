"use client"

import { useState, useEffect } from "react"
import { X, Users, Send, CheckCircle2, MessageCircle, ShieldCheck } from "lucide-react"
import { useTravelData } from "@/contexts/travel-data-context"

interface BookingModalProps {
  isOpen: boolean
  onClose: () => void
  preSelectedTrip?: string
}

export function BookingModal({ isOpen, onClose, preSelectedTrip }: BookingModalProps) {
  const { strangerTrips, brandInfo, addInquiry } = useTravelData()
  const [selectedTrip, setSelectedTrip] = useState<string>(preSelectedTrip || strangerTrips[0]?.title || "")
  const [name, setName] = useState("")
  const [phone, setPhone] = useState("")
  const [email, setEmail] = useState("")
  const [travellers, setTravellers] = useState(1)
  const [preferredDate, setPreferredDate] = useState("")
  const [pickupLocation, setPickupLocation] = useState("Kochi Vyttila Hub")
  const [message, setMessage] = useState("")
  const [submitted, setSubmitted] = useState(false)

  useEffect(() => {
    if (preSelectedTrip) setSelectedTrip(preSelectedTrip)
    else if (strangerTrips.length > 0 && !selectedTrip) setSelectedTrip(strangerTrips[0].title)
  }, [preSelectedTrip, strangerTrips, selectedTrip])

  if (!isOpen) return null

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!name || !phone) {
      alert("Please provide your name and phone number.")
      return
    }

    addInquiry({
      type: "stranger_trip",
      title: `Stranger Trip Registration: ${selectedTrip}`,
      customerName: name,
      phone,
      email,
      details: {
        tripTitle: selectedTrip,
        travellers,
        pickupLocation,
        preferredDate: preferredDate || "Upcoming Weekend Batch",
        notes: message || "Direct booking enquiry",
      },
    })

    setSubmitted(true)
  }

  const handleWhatsAppSend = () => {
    const cleanPhone = brandInfo.phone.replace(/[^0-9]/g, "")
    const text = encodeURIComponent(
      `Hi ${brandInfo.name}! I would like to join a Stranger Trip in Munnar.\n\n` +
        `• Trip: ${selectedTrip}\n` +
        `• Name: ${name || "Solo Traveler"}\n` +
        `• Phone: ${phone || "Not provided"}\n` +
        `• Travellers: ${travellers}\n` +
        `• Preferred Date: ${preferredDate || "Upcoming Weekend"}\n` +
        `• Pickup: ${pickupLocation}\n` +
        `• Message: ${message || "Ready to join!"}\n\nPlease confirm availability and details.`,
    )
    window.open(`https://wa.me/${cleanPhone}?text=${text}`, "_blank")
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-neutral-950 border-2 border-yellow-400 text-white rounded-2xl max-w-xl w-full max-h-[95vh] overflow-y-auto shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 bg-neutral-900 text-white hover:bg-yellow-400 hover:text-black p-2 rounded-full transition-colors"
          aria-label="Close booking modal"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="p-8 sm:p-10 text-center space-y-6">
            <div className="w-16 h-16 bg-yellow-400 text-black rounded-full flex items-center justify-center mx-auto border-2 border-black">
              <CheckCircle2 className="w-8 h-8 stroke-[2.5]" />
            </div>

            <div className="space-y-2">
              <span className="text-xs font-black uppercase tracking-widest bg-yellow-400 text-black px-2.5 py-0.5 rounded">ENQUIRY RECEIVED</span>
              <h3 className="text-2xl sm:text-3xl font-black uppercase text-white">You&apos;re on the list, {name}!</h3>
              <p className="text-xs sm:text-sm text-neutral-300 max-w-md mx-auto leading-relaxed">
                We have received your registration enquiry for <strong>{selectedTrip}</strong>. Our Munnar batch coordinator will contact you at{" "}
                <strong>{phone}</strong> to confirm your slot, verify pickup details, and answer any questions!
              </p>
            </div>

            <div className="bg-neutral-900 p-4 rounded-xl text-left text-xs space-y-1.5 border border-neutral-800">
              <div className="text-yellow-400 font-bold uppercase text-[10px]">Booking Summary:</div>
              <div>
                • Trip: <span className="font-extrabold text-white">{selectedTrip}</span>
              </div>
              <div>
                • Travellers: <span className="font-extrabold text-white">{travellers}</span>
              </div>
              <div>
                • Pickup Point: <span className="font-extrabold text-white">{pickupLocation}</span>
              </div>
              <div>
                • Preferred Date: <span className="font-extrabold text-white">{preferredDate || "Upcoming Weekend Batch"}</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={handleWhatsAppSend}
                className="flex-1 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Confirm on WhatsApp: {brandInfo.phoneDisplay}</span>
              </button>
              <button
                onClick={() => {
                  setSubmitted(false)
                  onClose()
                }}
                className="py-3.5 px-6 bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs uppercase tracking-wider rounded-lg transition-colors"
              >
                Close
              </button>
            </div>

            <div className="text-[11px] text-neutral-400 flex items-center justify-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-yellow-400" />
              <span>No instant payment deducted. Verification done by human host.</span>
            </div>
          </div>
        ) : (
          <div className="p-6 sm:p-8">
            <div className="space-y-1 mb-6 border-b border-neutral-800 pb-4">
              <span className="text-[10px] font-black uppercase tracking-widest bg-yellow-400 text-black px-2 py-0.5 rounded">STRANGER TRIPS ENQUIRY</span>
              <h3 className="text-2xl font-black uppercase tracking-tight text-white mt-2">Join a Stranger Batch</h3>
              <p className="text-xs text-neutral-400">Come as a stranger, leave as a story. Reserve your slot or enquire with our team.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-black uppercase text-neutral-300 mb-1">Selected Stranger Trip *</label>
                <select
                  value={selectedTrip}
                  onChange={(e) => setSelectedTrip(e.target.value)}
                  className="w-full px-3 py-2.5 bg-neutral-900 border border-neutral-700 rounded-lg text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                >
                  {strangerTrips.map((t) => (
                    <option key={t.id} value={t.title}>
                      {t.title} ({t.duration} - ₹{t.startingPrice})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-black uppercase text-neutral-300 mb-1">Your Name *</label>
                  <input
                    type="text"
                    placeholder="e.g. Arun Kumar"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-neutral-300 mb-1">Phone Number (WhatsApp) *</label>
                  <input
                    type="tel"
                    placeholder="e.g. 9876543210"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                    required
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-black uppercase text-neutral-300 mb-1">Email Address</label>
                  <input
                    type="email"
                    placeholder="you@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-neutral-300 mb-1">Number of Travellers</label>
                  <select
                    value={travellers}
                    onChange={(e) => setTravellers(Number.parseInt(e.target.value))}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                  >
                    <option value={1}>1 Solo Traveller</option>
                    <option value={2}>2 Friends / Pair</option>
                    <option value={3}>3 Travellers</option>
                    <option value={4}>4 Travellers</option>
                  </select>
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-black uppercase text-neutral-300 mb-1">Preferred Batch Date</label>
                  <input
                    type="date"
                    value={preferredDate}
                    onChange={(e) => setPreferredDate(e.target.value)}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-neutral-300 mb-1">Pickup Location</label>
                  <select
                    value={pickupLocation}
                    onChange={(e) => setPickupLocation(e.target.value)}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                  >
                    <option value="Kochi Vyttila Hub">Kochi Vyttila Hub</option>
                    <option value="Aluva Metro Station">Aluva Metro Station</option>
                    <option value="Cochin International Airport (COK)">Cochin Airport (COK)</option>
                    <option value="Munnar Town Center">Munnar Town Center</option>
                    <option value="Other / Self Arrival">Other / Self Arrival</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-black uppercase text-neutral-300 mb-1">Message / Dietary / Any Questions</label>
                <textarea
                  rows={2}
                  placeholder="Tell us if this is your first solo trip, if you need vegetarian meals, or have pickup questions..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-sm text-white font-medium focus:outline-none focus:border-yellow-400"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-4 bg-yellow-400 hover:bg-yellow-300 text-black font-black text-sm uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                >
                  <Send className="w-4 h-4 text-black" />
                  <span>Submit Trip Enquiry</span>
                </button>
              </div>

              <div className="flex items-center justify-between text-[11px] text-neutral-400 pt-2 border-t border-neutral-800">
                <span>
                  Direct Support: <strong className="text-white">{brandInfo.phoneDisplay}</strong>
                </span>
                <a href={brandInfo.whatsapp} target="_blank" rel="noopener noreferrer" className="text-yellow-400 hover:underline flex items-center gap-1">
                  <MessageCircle className="w-3 h-3" />
                  <span>WhatsApp Help</span>
                </a>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  )
}
