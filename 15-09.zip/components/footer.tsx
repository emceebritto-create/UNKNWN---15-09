"use client"

import Link from "next/link"
import { Phone, Mail, MapPin, MessageCircle, Users, Compass, Briefcase, ArrowUp, ShieldCheck } from "lucide-react"
import { useTravelData } from "@/contexts/travel-data-context"

interface FooterProps {
  onNavigate: (sectionId: string) => void
  onOpenBooking: () => void
  onOpenCustomTour: () => void
}

export function Footer({ onNavigate, onOpenBooking, onOpenCustomTour }: FooterProps) {
  const { brandInfo, strangerTrips } = useTravelData()

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: "smooth" })

  return (
    <footer className="bg-black text-white border-t-4 border-yellow-400">
      <div className="bg-yellow-400 text-black py-8 px-4 sm:px-6 lg:px-8 border-b-2 border-black">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <span className="text-[11px] font-black uppercase tracking-widest bg-black text-yellow-400 px-2 py-0.5 rounded inline-block">
              {brandInfo.tagline}
            </span>
            <h3 className="text-2xl sm:text-3xl font-black uppercase tracking-tight text-black">
              {brandInfo.heroHeadlineLine1} {brandInfo.heroHeadlineAccent} {brandInfo.heroHeadlineLine2} {brandInfo.heroHeadlineEnding}
            </h3>
            <p className="text-xs sm:text-sm font-bold text-neutral-900">
              Munnar&apos;s premier stranger community batches, custom private journeys, and licensed DMC partner.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <a
              href={`tel:${brandInfo.phone}`}
              className="px-6 py-3 bg-black hover:bg-neutral-900 text-yellow-400 font-black text-xs uppercase tracking-wider rounded-lg transition-colors flex items-center gap-2"
            >
              <Phone className="w-4 h-4" />
              <span>Call {brandInfo.phoneDisplay}</span>
            </a>
            <a
              href={brandInfo.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 bg-white hover:bg-neutral-100 text-black font-black text-xs uppercase tracking-wider rounded-lg border-2 border-black transition-colors flex items-center gap-2"
            >
              <MessageCircle className="w-4 h-4 text-emerald-600" />
              <span>WhatsApp Us</span>
            </a>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <span className="text-3xl font-black tracking-tighter text-white flex items-center gap-1">
                {brandInfo.name}
                <span className="w-3 h-3 rounded-sm bg-yellow-400 inline-block" />
              </span>
            </div>

            <p className="text-xs sm:text-sm text-neutral-400 font-medium leading-relaxed max-w-sm">
              {brandInfo.tagline} — UNKNWN is a modern travel startup rooted in Munnar, Kerala. We curate group batches for solo travelers to connect,
              organize private bespoke itineraries, and provide robust B2B destination coordination.
            </p>

            <div className="space-y-2 text-xs font-semibold text-neutral-300 pt-2">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-yellow-400 shrink-0" />
                <a href={`tel:${brandInfo.phone}`} className="hover:text-yellow-400 font-bold transition-colors">
                  {brandInfo.phoneDisplay}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-yellow-400 shrink-0" />
                <span>{brandInfo.email}</span>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
                <span className="text-neutral-400 leading-snug">{brandInfo.location}</span>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <div className="text-xs font-black uppercase tracking-widest text-yellow-400 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5" />
              <span>AREA 1: STRANGER</span>
            </div>
            <ul className="space-y-2 text-xs font-bold text-neutral-300">
              {strangerTrips.slice(0, 3).map((trip) => (
                <li key={trip.id}>
                  <button onClick={() => onNavigate("stranger-trips")} className="hover:text-yellow-400 transition-colors text-left truncate max-w-[200px]">
                    {trip.title}
                  </button>
                </li>
              ))}
              <li>
                <button onClick={onOpenBooking} className="text-yellow-400 hover:underline inline-flex items-center gap-1 mt-1">
                  <span>Join Next Batch →</span>
                </button>
              </li>
            </ul>
          </div>

          <div className="space-y-3">
            <div className="text-xs font-black uppercase tracking-widest text-yellow-400 flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5" />
              <span>AREA 2: NORMAL TOURS</span>
            </div>
            <ul className="space-y-2 text-xs font-bold text-neutral-300">
              <li>
                <button onClick={() => onNavigate("custom-tours")} className="hover:text-yellow-400 transition-colors text-left">
                  Custom Itinerary Builder
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate("custom-tours")} className="hover:text-yellow-400 transition-colors text-left">
                  Family & Couple Private Tours
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate("custom-tours")} className="hover:text-yellow-400 transition-colors text-left">
                  Resort & Tea Cottage Stays
                </button>
              </li>
              <li>
                <button onClick={onOpenCustomTour} className="text-white hover:text-yellow-400 hover:underline inline-flex items-center gap-1 mt-1">
                  <span>Build My Tour →</span>
                </button>
              </li>
            </ul>
          </div>

          <div className="space-y-3">
            <div className="text-xs font-black uppercase tracking-widest text-yellow-400 flex items-center gap-1.5">
              <Briefcase className="w-3.5 h-3.5" />
              <span>AREA 3: UNKNWN DMC</span>
            </div>
            <ul className="space-y-2 text-xs font-bold text-neutral-300">
              <li>
                <button onClick={() => onNavigate("dmc")} className="hover:text-yellow-400 transition-colors text-left">
                  B2B Travel Agency Contracting
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate("dmc")} className="hover:text-yellow-400 transition-colors text-left">
                  Corporate Offsites & Retreats
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate("dmc")} className="hover:text-yellow-400 transition-colors text-left">
                  4x4 Jeep & Tempo Fleets
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate("dmc")} className="hover:text-yellow-400 transition-colors text-left">
                  Destination Coordination
                </button>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-neutral-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500 font-semibold">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <span>
              © {new Date().getFullYear()} {brandInfo.name} • {brandInfo.tagline}. All rights reserved.
            </span>
          </div>
          <div className="flex items-center gap-4">
            <a href={`tel:${brandInfo.phone}`} className="hover:text-yellow-400 transition-colors">
              Phone: {brandInfo.phoneDisplay}
            </a>
            <span>•</span>
            <Link href="/admin/login" className="hover:text-yellow-400 transition-colors flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Admin Login</span>
            </Link>
            <span>•</span>
            <button onClick={scrollToTop} className="hover:text-yellow-400 transition-colors flex items-center gap-1">
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-2">
        <a
          href={brandInfo.whatsapp}
          target="_blank"
          rel="noopener noreferrer"
          className="bg-emerald-500 hover:bg-emerald-600 text-white p-3.5 rounded-full shadow-2xl flex items-center gap-2 font-black text-xs uppercase tracking-wider border-2 border-white transition-transform hover:scale-105"
          aria-label={`Chat on WhatsApp with ${brandInfo.name}`}
        >
          <MessageCircle className="w-6 h-6" />
          <span className="hidden md:inline">WhatsApp: {brandInfo.phoneDisplay}</span>
        </a>
      </div>
    </footer>
  )
}
