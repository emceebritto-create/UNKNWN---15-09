"use client"

import { useState } from "react"
import { Briefcase, CheckCircle2, Phone, Send, Layers, ArrowRight } from "lucide-react"
import { useTravelData } from "@/contexts/travel-data-context"
import { ScrollFadeSection } from "@/components/scroll-fade-section"

interface DmcFormData {
  name: string
  company: string
  phone: string
  email: string
  travelDates: string
  groupSize: string
  destination: string
  servicesRequired: string[]
  budget: string
  message: string
}

export function DmcSection() {
  const { dmcData, brandInfo, addInquiry } = useTravelData()
  const [formData, setFormData] = useState<DmcFormData>({
    name: "",
    company: "",
    phone: "",
    email: "",
    travelDates: "",
    groupSize: "10–30 Pax",
    destination: "Munnar & High Ranges (Kerala)",
    servicesRequired: ["Customized itineraries", "Accommodation arrangements", "Transportation"],
    budget: "",
    message: "",
  })

  const [submitted, setSubmitted] = useState(false)

  const availableServices = [
    "Customized itineraries",
    "Group travel",
    "Corporate travel",
    "Accommodation arrangements",
    "Transportation",
    "Local experiences",
    "Travel agency support",
    "Destination coordination",
    "On-ground travel assistance",
    "Private group arrangements",
    "Event and travel coordination",
  ]

  const handleToggleService = (service: string) => {
    setFormData((prev) => ({
      ...prev,
      servicesRequired: prev.servicesRequired.includes(service)
        ? prev.servicesRequired.filter((s) => s !== service)
        : [...prev.servicesRequired, service],
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.name || !formData.phone) {
      alert("Please provide your name and phone number.")
      return
    }

    addInquiry({
      type: "dmc",
      title: `UNKNWN DMC B2B Enquiry (${formData.company || formData.name})`,
      customerName: formData.name,
      phone: formData.phone,
      email: formData.email,
      details: {
        company: formData.company || "Direct Planner",
        groupSize: formData.groupSize,
        travelDates: formData.travelDates || "Flexible",
        services: formData.servicesRequired,
        budget: formData.budget || "Custom RFP",
        message: formData.message || "B2B contracting enquiry",
      },
    })

    setSubmitted(true)
  }

  return (
    <ScrollFadeSection>
      <section id="dmc" className="py-20 sm:py-28 bg-neutral-950 text-white relative border-b border-neutral-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4 mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-yellow-400 text-black text-xs font-black uppercase tracking-wider">
              <Briefcase className="w-3.5 h-3.5" />
              <span>{dmcData.badge}</span>
            </div>

            <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black uppercase tracking-tight text-white">
              {dmcData.headline} <br />
              <span className="text-yellow-400">{dmcData.highlightWord}</span>
            </h2>

            <p className="text-neutral-300 text-base sm:text-lg font-medium leading-relaxed">{dmcData.subheadline}</p>

            <div className="flex items-center gap-4 text-xs font-extrabold text-neutral-400 pt-1">
              <span className="text-yellow-400">●</span> 100% Local On-Ground Team Stationed in Munnar
              <span className="text-yellow-400">●</span> Direct Contracting With Resorts & 4x4 Fleets
            </div>
          </div>

          <div className="mb-14">
            <div className="text-xs font-black uppercase tracking-widest text-neutral-400 mb-3">TRUSTED PARTNER FOR:</div>
            <div className="flex flex-wrap gap-2">
              {dmcData.targetAudience.map((audience, i) => (
                <span
                  key={i}
                  className="px-3.5 py-2 rounded-md bg-neutral-900 border border-neutral-800 text-xs font-bold text-neutral-200 hover:border-yellow-400 transition-colors"
                >
                  {audience}
                </span>
              ))}
            </div>
          </div>

          <div className="mb-16">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl sm:text-2xl font-black uppercase tracking-tight text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-yellow-400" />
                <span>DMC Services & Capabilities ({dmcData.services.length})</span>
              </h3>
              <span className="text-xs text-neutral-400 font-semibold hidden sm:inline">Munnar & Idukki High Ranges</span>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
              {dmcData.services.map((srv, idx) => (
                <div key={idx} className="bg-neutral-900/90 p-5 rounded-xl border border-neutral-800 hover:border-yellow-400/80 transition-all group">
                  <div className="w-8 h-8 rounded bg-yellow-400/10 border border-yellow-400/30 text-yellow-400 flex items-center justify-center text-xs font-black mb-3 group-hover:bg-yellow-400 group-hover:text-black transition-colors">
                    0{idx + 1}
                  </div>
                  <h4 className="text-sm font-black uppercase text-white tracking-tight mb-1.5">{srv.title}</h4>
                  <p className="text-xs text-neutral-400 font-medium leading-relaxed">{srv.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-neutral-900 rounded-2xl border-2 border-yellow-400/60 overflow-hidden shadow-2xl">
            <div className="grid lg:grid-cols-12">
              <div className="lg:col-span-5 p-6 sm:p-10 bg-black flex flex-col justify-between space-y-8 border-b lg:border-b-0 lg:border-r border-neutral-800">
                <div className="space-y-6">
                  <span className="text-[11px] font-black uppercase tracking-widest bg-yellow-400 text-black px-2.5 py-1 rounded inline-block">
                    B2B COLLABORATION
                  </span>

                  <h3 className="text-2xl sm:text-3xl font-black uppercase text-white tracking-tight">Work with UNKNWN</h3>

                  <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed font-medium">
                    Whether you are an out-of-state travel agent booking Kerala itineraries, an HR team planning an executive leadership retreat, or an
                    event company organizing a shoot, we handle everything on the ground in Munnar.
                  </p>

                  <div className="space-y-3 text-xs text-neutral-300 font-semibold pt-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
                      <span>Dedicated local operations manager assigned to your group</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
                      <span>Transparent wholesale B2B pricing & prompt GST billing</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
                      <span>Fleet of 4x4 Jeeps, Tempo Travellers, and experienced drivers</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
                      <span>
                        Real-time on-ground support line: <strong className="text-white">{brandInfo.phoneDisplay}</strong>
                      </span>
                    </div>
                  </div>
                </div>

                <div className="bg-neutral-900 p-4 rounded-xl border border-neutral-800 space-y-2">
                  <div className="text-[11px] font-black uppercase text-neutral-400">Direct DMC Desk:</div>
                  <div className="flex items-center justify-between">
                    <a href={`tel:${brandInfo.phone}`} className="text-sm font-black text-yellow-400 hover:underline flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5" />
                      <span>{brandInfo.phoneDisplay}</span>
                    </a>
                    <a
                      href={brandInfo.whatsapp}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-bold bg-yellow-400 text-black px-2.5 py-1 rounded hover:bg-yellow-300 transition-colors"
                    >
                      B2B WhatsApp
                    </a>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-7 p-6 sm:p-10 bg-neutral-950">
                {submitted ? (
                  <div className="py-12 text-center space-y-5">
                    <div className="w-16 h-16 rounded-full bg-yellow-400 text-black flex items-center justify-center mx-auto">
                      <CheckCircle2 className="w-8 h-8 stroke-[2.5]" />
                    </div>
                    <div className="space-y-1">
                      <span className="text-xs font-black uppercase tracking-widest text-yellow-400">B2B ENQUIRY LOGGED</span>
                      <h4 className="text-2xl font-black uppercase text-white">Thank You, {formData.name}!</h4>
                      <p className="text-xs text-neutral-400 max-w-md mx-auto">
                        Our Head of Destination Operations will review your requirements for <strong>{formData.company || "your organization"}</strong> and
                        get in touch at <strong>{formData.phone}</strong> with a comprehensive proposal.
                      </p>
                    </div>
                    <button
                      onClick={() => setSubmitted(false)}
                      className="px-5 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-bold uppercase rounded"
                    >
                      Submit Another Inquiry
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
                      <h4 className="text-base font-black uppercase text-white tracking-tight flex items-center gap-2">
                        <Send className="w-4 h-4 text-yellow-400" />
                        <span>DMC Partnership Enquiry</span>
                      </h4>
                      <span className="text-[10px] uppercase font-bold text-neutral-400">Response within 2 hours</span>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[11px] font-black uppercase tracking-wider text-neutral-300 mb-1">Contact Person Name *</label>
                        <input
                          type="text"
                          placeholder="e.g. Anand Menon"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-black uppercase tracking-wider text-neutral-300 mb-1">Company / Agency / Group Name</label>
                        <input
                          type="text"
                          placeholder="e.g. Wanderlust Travels / Infosys Offsite"
                          value={formData.company}
                          onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                          className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-black uppercase tracking-wider text-neutral-300 mb-1">Phone / WhatsApp *</label>
                        <input
                          type="tel"
                          placeholder="e.g. 9876543210"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-black uppercase tracking-wider text-neutral-300 mb-1">Business Email</label>
                        <input
                          type="email"
                          placeholder="contact@company.com"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-black uppercase tracking-wider text-neutral-300 mb-1">Tentative Travel Dates</label>
                        <input
                          type="text"
                          placeholder="e.g. Next Month / 15-18 Oct"
                          value={formData.travelDates}
                          onChange={(e) => setFormData({ ...formData, travelDates: e.target.value })}
                          className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-black uppercase tracking-wider text-neutral-300 mb-1">Approx Group Size</label>
                        <select
                          value={formData.groupSize}
                          onChange={(e) => setFormData({ ...formData, groupSize: e.target.value })}
                          className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                        >
                          <option value="1–5 Pax (Private)">1–5 Pax (Private)</option>
                          <option value="6–15 Pax (Small Group)">6–15 Pax (Small Group)</option>
                          <option value="15–30 Pax (Corporate / College)">15–30 Pax (Corporate / College)</option>
                          <option value="30–60 Pax (Large Group)">30–60 Pax (Large Group)</option>
                          <option value="60+ Pax (MICE / Convention)">60+ Pax (MICE / Convention)</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-black uppercase tracking-wider text-neutral-300 mb-2">Services Required (Multi-Select)</label>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {availableServices.map((srv) => {
                          const isChecked = formData.servicesRequired.includes(srv)
                          return (
                            <button
                              type="button"
                              key={srv}
                              onClick={() => handleToggleService(srv)}
                              className={`p-2 rounded text-[11px] font-bold text-left border transition-all ${
                                isChecked ? "bg-yellow-400 text-black border-yellow-400" : "bg-neutral-900 text-neutral-300 border-neutral-800 hover:border-neutral-700"
                              }`}
                            >
                              <span className="mr-1 font-black">{isChecked ? "✓" : "+"}</span>
                              {srv}
                            </button>
                          )
                        })}
                      </div>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[11px] font-black uppercase tracking-wider text-neutral-300 mb-1">Approx Budget / Target Price</label>
                        <input
                          type="text"
                          placeholder="e.g. ₹3,500/head or ₹1.5 Lakh total"
                          value={formData.budget}
                          onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                          className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-black uppercase tracking-wider text-neutral-300 mb-1">Destination Scope</label>
                        <input
                          type="text"
                          value={formData.destination}
                          onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                          className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded text-sm text-white font-bold focus:outline-none focus:border-yellow-400"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-black uppercase tracking-wider text-neutral-300 mb-1">Project Notes / Special Requirements</label>
                      <textarea
                        rows={2}
                        placeholder="Specify dates, special hotel tiers, team activity goals, vehicle requirements, etc."
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded text-sm text-white font-medium focus:outline-none focus:border-yellow-400"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3.5 bg-yellow-400 hover:bg-yellow-300 text-black font-black text-sm uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                    >
                      <span>WORK WITH UNKNWN</span>
                      <ArrowRight className="w-4 h-4 text-black" />
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </ScrollFadeSection>
  )
}
