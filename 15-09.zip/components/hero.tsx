"use client"

import { Users, Compass, Sparkles, MapPin, ArrowRight, CheckCircle2 } from "lucide-react"
import { useTravelData } from "@/contexts/travel-data-context"
import { ScrollFadeSection } from "@/components/scroll-fade-section"

interface HeroProps {
  onExploreStrangerTrips: () => void
  onPlanNormalTour: () => void
  onOpenBooking: () => void
}

export function Hero({ onExploreStrangerTrips, onPlanNormalTour, onOpenBooking }: HeroProps) {
  const { brandInfo, strangerTrips } = useTravelData()
  const featuredBatch = strangerTrips[0]

  return (
    <ScrollFadeSection>
      <section id="home" className="relative min-h-[92vh] bg-black text-white flex items-center overflow-hidden border-b border-neutral-800">
        <div className="absolute inset-0 z-0">
          <img
            src={brandInfo.heroImage || "/placeholder.svg"}
            alt="Munnar Kerala misty green tea hills and cloud valley"
            crossOrigin="anonymous"
            className="w-full h-full object-cover object-center scale-105 filter brightness-[0.42] contrast-[1.15]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-black/30" />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent lg:w-3/4" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 w-full">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-8 space-y-6 sm:space-y-8">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-yellow-400 text-black font-black text-xs uppercase tracking-wider shadow-lg">
                <Sparkles className="w-3.5 h-3.5 fill-black" />
                <span>{brandInfo.tagline}</span>
                <span className="w-1.5 h-1.5 bg-black rounded-full" />
                <span className="font-extrabold text-[11px]">Munnar, Kerala</span>
              </div>

              <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-black uppercase tracking-tight leading-[0.95] text-white">
                {brandInfo.heroHeadlineLine1} <br />
                <span className="text-yellow-400 inline-block drop-shadow-sm underline decoration-yellow-400/40 decoration-wavy decoration-2">
                  {brandInfo.heroHeadlineAccent}
                </span>{" "}
                <br />
                {brandInfo.heroHeadlineLine2} <br />
                <span className="text-white">{brandInfo.heroHeadlineEnding}</span>
              </h1>

              <p className="text-lg sm:text-2xl text-neutral-200 font-semibold max-w-2xl leading-relaxed">{brandInfo.heroSubtitle}</p>

              <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm font-bold text-neutral-300 pt-2">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
                  <span>Curated Groups of 10–14</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
                  <span>Kolukkumalai & Cloud Camp</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
                  <span>Direct Local Concierge: {brandInfo.phoneDisplay}</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-4">
                <button
                  onClick={onExploreStrangerTrips}
                  className="px-8 py-4 rounded-md bg-yellow-400 hover:bg-yellow-300 text-black font-black text-base uppercase tracking-wider transition-all duration-200 shadow-xl shadow-yellow-400/20 flex items-center justify-center gap-2 group cursor-pointer"
                >
                  <Users className="w-5 h-5 text-black stroke-[2.5]" />
                  <span>Explore Stranger Trips</span>
                  <ArrowRight className="w-5 h-5 text-black group-hover:translate-x-1 transition-transform" />
                </button>

                <button
                  onClick={onPlanNormalTour}
                  className="px-8 py-4 rounded-md bg-transparent hover:bg-white hover:text-black text-white border-2 border-white font-black text-base uppercase tracking-wider transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Compass className="w-5 h-5 stroke-[2.5]" />
                  <span>Plan a Normal Tour</span>
                </button>
              </div>

              <div className="grid grid-cols-3 gap-3 pt-6 border-t border-neutral-800/80 max-w-xl">
                <div className="bg-neutral-900/90 p-3 rounded border border-neutral-800">
                  <div className="text-yellow-400 font-black text-xs uppercase tracking-wider">AREA 1</div>
                  <div className="text-white font-extrabold text-sm sm:text-base">Stranger Trips</div>
                  <div className="text-neutral-400 text-xs mt-0.5">Solo Travellers & Friends</div>
                </div>
                <div className="bg-neutral-900/90 p-3 rounded border border-neutral-800">
                  <div className="text-white font-black text-xs uppercase tracking-wider">AREA 2</div>
                  <div className="text-white font-extrabold text-sm sm:text-base">Normal Tours</div>
                  <div className="text-neutral-400 text-xs mt-0.5">Custom Private Travel</div>
                </div>
                <div className="bg-neutral-900/90 p-3 rounded border border-neutral-800">
                  <div className="text-yellow-400 font-black text-xs uppercase tracking-wider">AREA 3</div>
                  <div className="text-white font-extrabold text-sm sm:text-base">UNKNWN DMC</div>
                  <div className="text-neutral-400 text-xs mt-0.5">B2B Destination Partner</div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-4">
              {featuredBatch && (
                <div className="bg-yellow-400 text-black p-6 rounded-xl shadow-2xl space-y-4 border-4 border-black relative">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-[11px] font-black uppercase tracking-widest bg-black text-yellow-400 px-2.5 py-1 rounded">FEATURED BATCH</span>
                      <h2 className="text-2xl font-black uppercase tracking-tight mt-2 leading-tight">{featuredBatch.title}</h2>
                    </div>
                    <div className="text-right">
                      {featuredBatch.originalPrice && <div className="text-xs font-bold text-black/70 line-through">₹{featuredBatch.originalPrice}</div>}
                      <div className="text-2xl font-black text-black">₹{featuredBatch.startingPrice}</div>
                      <div className="text-[10px] font-extrabold uppercase">per person</div>
                    </div>
                  </div>

                  <div className="relative rounded-lg overflow-hidden h-40 border-2 border-black">
                    <img src={featuredBatch.image || "/placeholder.svg"} alt={featuredBatch.title} crossOrigin="anonymous" className="w-full h-full object-cover" />
                    <div className="absolute bottom-2 left-2 bg-black/90 text-white text-[11px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-yellow-400" />
                      <span>{featuredBatch.pickupLocations[0] || "Munnar"}</span>
                    </div>
                  </div>

                  <div className="space-y-2 text-xs font-bold text-neutral-900">
                    <div className="flex items-center justify-between border-b border-black/15 pb-1.5">
                      <span className="text-neutral-800">Departure:</span>
                      <span className="font-extrabold">{featuredBatch.dates}</span>
                    </div>
                    <div className="flex items-center justify-between border-b border-black/15 pb-1.5">
                      <span className="text-neutral-800">Pickups:</span>
                      <span className="font-extrabold truncate max-w-[170px]">{featuredBatch.pickupLocations.join(" / ")}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-800">Slots Left:</span>
                      <span className="bg-black text-yellow-400 px-2 py-0.5 rounded font-black text-[11px] animate-pulse">
                        Only {featuredBatch.remainingSlots} Slots
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={onOpenBooking}
                    className="w-full py-3.5 bg-black hover:bg-neutral-900 text-yellow-400 font-black text-sm uppercase tracking-wider rounded-md transition-colors flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Grab Your Slot</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </ScrollFadeSection>
  )
}
