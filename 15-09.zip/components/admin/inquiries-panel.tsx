"use client"

import { useState } from "react"
import { useTravelData } from "@/contexts/travel-data-context"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronUp, Trash2, Phone, Mail, Inbox } from "lucide-react"
import type { InquiryRecord } from "@/lib/types"

const STATUS_OPTIONS: InquiryRecord["status"][] = ["New", "Contacted", "Confirmed", "Archived"]

const STATUS_STYLES: Record<InquiryRecord["status"], string> = {
  New: "bg-amber-500/15 text-amber-400 border-amber-500/30",
  Contacted: "bg-blue-500/15 text-blue-400 border-blue-500/30",
  Confirmed: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
  Archived: "bg-neutral-500/15 text-neutral-400 border-neutral-500/30",
}

export function InquiriesPanel() {
  const { inquiries, updateInquiryStatus, deleteInquiry } = useTravelData()
  const [expandedId, setExpandedId] = useState<string | null>(null)

  if (inquiries.length === 0) {
    return (
      <div className="flex max-w-3xl flex-col items-center gap-3 rounded-xl border border-white/10 bg-neutral-950 p-12 text-center">
        <Inbox className="size-8 text-neutral-600" aria-hidden="true" />
        <p className="font-medium text-white">No inquiries yet</p>
        <p className="text-sm text-neutral-500">Customer submissions from booking forms and contact requests will appear here.</p>
      </div>
    )
  }

  return (
    <div className="flex max-w-3xl flex-col gap-3">
      <p className="text-sm text-neutral-400">{inquiries.length} total inquiries</p>
      {inquiries.map((inquiry) => (
        <div key={inquiry.id} className="rounded-xl border border-white/10 bg-neutral-950">
          <button
            onClick={() => setExpandedId(expandedId === inquiry.id ? null : inquiry.id)}
            className="flex w-full items-center justify-between gap-3 p-4 text-left"
          >
            <div className="flex flex-1 flex-col gap-1 sm:flex-row sm:items-center sm:gap-3">
              <span className="font-semibold text-white">{inquiry.customerName}</span>
              <span className="text-sm text-neutral-500">{inquiry.title}</span>
              <span className="text-xs text-neutral-600">{inquiry.dateSubmitted}</span>
            </div>
            <Badge variant="outline" className={STATUS_STYLES[inquiry.status]}>
              {inquiry.status}
            </Badge>
            {expandedId === inquiry.id ? (
              <ChevronUp className="size-4 shrink-0 text-neutral-400" />
            ) : (
              <ChevronDown className="size-4 shrink-0 text-neutral-400" />
            )}
          </button>

          {expandedId === inquiry.id ? (
            <div className="flex flex-col gap-4 border-t border-white/10 p-4">
              <div className="flex flex-wrap gap-4 text-sm text-neutral-300">
                <a href={`tel:${inquiry.phone}`} className="flex items-center gap-1.5 hover:text-amber-400">
                  <Phone className="size-4" aria-hidden="true" /> {inquiry.phone}
                </a>
                {inquiry.email ? (
                  <a href={`mailto:${inquiry.email}`} className="flex items-center gap-1.5 hover:text-amber-400">
                    <Mail className="size-4" aria-hidden="true" /> {inquiry.email}
                  </a>
                ) : null}
                {inquiry.preferredDate ? <span>Preferred date: {inquiry.preferredDate}</span> : null}
              </div>

              {Object.keys(inquiry.details).length > 0 ? (
                <dl className="grid grid-cols-1 gap-2 rounded-lg border border-white/10 bg-neutral-900 p-3 text-sm sm:grid-cols-2">
                  {Object.entries(inquiry.details).map(([key, value]) => (
                    <div key={key} className="flex flex-col">
                      <dt className="text-xs uppercase tracking-wide text-neutral-500">{key}</dt>
                      <dd className="text-neutral-200">{Array.isArray(value) ? value.join(", ") : String(value)}</dd>
                    </div>
                  ))}
                </dl>
              ) : null}

              <div className="flex flex-wrap items-center gap-3">
                <select
                  value={inquiry.status}
                  onChange={(e) => updateInquiryStatus(inquiry.id, e.target.value as InquiryRecord["status"])}
                  className="rounded-md border border-white/10 bg-neutral-900 px-3 py-2 text-sm text-white"
                >
                  {STATUS_OPTIONS.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => deleteInquiry(inquiry.id)}
                  className="ml-auto border-red-500/30 text-red-400 hover:bg-red-500/10"
                >
                  <Trash2 className="size-4" aria-hidden="true" /> Delete
                </Button>
              </div>
            </div>
          ) : null}
        </div>
      ))}
    </div>
  )
}
