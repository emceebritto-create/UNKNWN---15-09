"use client"

import { useState } from "react"
import { useTravelData } from "@/contexts/travel-data-context"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ImageUploadField } from "@/components/admin/image-upload-field"
import { ListEditor } from "@/components/admin/list-editor"
import { Check, ChevronDown, ChevronUp, Plus, Trash2 } from "lucide-react"
import type { ServiceCardItem } from "@/lib/types"

const CATEGORIES: ServiceCardItem["category"][] = ["Stranger", "Custom", "Transport", "Adventure", "Stay"]

function emptyService(): ServiceCardItem {
  return {
    id: `service-${Date.now()}`,
    title: "NEW SERVICE",
    subtitle: "",
    description: "",
    image: "",
    features: [],
    category: "Custom",
  }
}

export function ServicesEditor() {
  const { servicesList, updateServiceItem, addServiceItem, deleteServiceItem } = useTravelData()
  const [expandedId, setExpandedId] = useState<string | null>(servicesList[0]?.id ?? null)
  const [savedId, setSavedId] = useState<string | null>(null)

  return (
    <div className="flex max-w-3xl flex-col gap-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-neutral-400">{servicesList.length} services listed on the site</p>
        <Button
          size="sm"
          onClick={() => {
            const item = emptyService()
            addServiceItem(item)
            setExpandedId(item.id)
          }}
          className="bg-amber-500 text-black hover:bg-amber-400"
        >
          <Plus className="size-4" aria-hidden="true" /> Add Service
        </Button>
      </div>

      {servicesList.map((service) => (
        <ServiceRow
          key={service.id}
          service={service}
          isExpanded={expandedId === service.id}
          isSaved={savedId === service.id}
          onToggle={() => setExpandedId(expandedId === service.id ? null : service.id)}
          onSave={(updated) => {
            updateServiceItem(updated)
            setSavedId(updated.id)
            setTimeout(() => setSavedId(null), 2000)
          }}
          onDelete={() => deleteServiceItem(service.id)}
        />
      ))}
    </div>
  )
}

function ServiceRow({
  service,
  isExpanded,
  isSaved,
  onToggle,
  onSave,
  onDelete,
}: {
  service: ServiceCardItem
  isExpanded: boolean
  isSaved: boolean
  onToggle: () => void
  onSave: (item: ServiceCardItem) => void
  onDelete: () => void
}) {
  const [form, setForm] = useState<ServiceCardItem>(service)

  const set = <K extends keyof ServiceCardItem>(key: K, value: ServiceCardItem[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  return (
    <div className="rounded-xl border border-white/10 bg-neutral-950">
      <button onClick={onToggle} className="flex w-full items-center justify-between gap-3 p-4 text-left">
        <div className="flex items-center gap-3">
          <span className="font-semibold text-white">{form.title}</span>
          <Badge variant="outline" className="border-white/20 text-neutral-400">
            {form.category}
          </Badge>
        </div>
        {isExpanded ? <ChevronUp className="size-4 text-neutral-400" /> : <ChevronDown className="size-4 text-neutral-400" />}
      </button>

      {isExpanded ? (
        <div className="flex flex-col gap-4 border-t border-white/10 p-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex flex-col gap-1.5">
              <Label className="text-neutral-300">Title</Label>
              <Input value={form.title} onChange={(e) => set("title", e.target.value)} className="border-white/10 bg-neutral-900 text-white" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-neutral-300">Category</Label>
              <select
                value={form.category}
                onChange={(e) => set("category", e.target.value as ServiceCardItem["category"])}
                className="rounded-md border border-white/10 bg-neutral-900 px-3 py-2 text-sm text-white"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <div className="sm:col-span-2">
              <Label className="text-neutral-300">Subtitle</Label>
              <Input
                value={form.subtitle}
                onChange={(e) => set("subtitle", e.target.value)}
                className="mt-1.5 border-white/10 bg-neutral-900 text-white"
              />
            </div>
            <div className="sm:col-span-2">
              <Label className="text-neutral-300">Description</Label>
              <Textarea
                value={form.description}
                onChange={(e) => set("description", e.target.value)}
                className="mt-1.5 min-h-20 border-white/10 bg-neutral-900 text-white"
              />
            </div>
            <div className="sm:col-span-2">
              <ImageUploadField label="Service Photo" value={form.image} onChange={(v) => set("image", v)} />
            </div>
            <div className="sm:col-span-2">
              <ListEditor label="Features" items={form.features} onChange={(items) => set("features", items)} placeholder="Add a feature" />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button onClick={() => onSave(form)} size="sm" className="bg-amber-500 text-black hover:bg-amber-400">
              Save
            </Button>
            {isSaved ? (
              <span className="flex items-center gap-1.5 text-sm text-emerald-400">
                <Check className="size-4" aria-hidden="true" /> Saved
              </span>
            ) : null}
            <Button onClick={onDelete} size="sm" variant="outline" className="ml-auto border-red-500/30 text-red-400 hover:bg-red-500/10">
              <Trash2 className="size-4" aria-hidden="true" /> Delete
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  )
}
