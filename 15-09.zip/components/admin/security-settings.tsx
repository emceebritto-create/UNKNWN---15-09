"use client"

import { useState, type FormEvent } from "react"
import { useAdminAuth } from "@/contexts/admin-auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ShieldCheck, ShieldAlert } from "lucide-react"

export function SecuritySettings() {
  const { adminEmail, usingDefaultCredentials, updateCredentials } = useAdminAuth()
  const [currentPassword, setCurrentPassword] = useState("")
  const [newEmail, setNewEmail] = useState(adminEmail)
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess(false)

    if (newPassword && newPassword !== confirmPassword) {
      setError("New password and confirmation do not match.")
      return
    }

    const result = await updateCredentials({
      currentPassword,
      newEmail,
      newPassword: newPassword || undefined,
    })

    if (!result.success) {
      setError(result.error ?? "Something went wrong.")
      return
    }

    setSuccess(true)
    setCurrentPassword("")
    setNewPassword("")
    setConfirmPassword("")
  }

  return (
    <div className="flex flex-col gap-6">
      <div
        className={
          usingDefaultCredentials
            ? "flex items-start gap-3 rounded-xl border border-red-500/30 bg-red-500/10 p-4"
            : "flex items-start gap-3 rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-4"
        }
      >
        {usingDefaultCredentials ? (
          <ShieldAlert className="mt-0.5 size-5 shrink-0 text-red-400" aria-hidden="true" />
        ) : (
          <ShieldCheck className="mt-0.5 size-5 shrink-0 text-emerald-400" aria-hidden="true" />
        )}
        <div>
          <p className={usingDefaultCredentials ? "font-semibold text-red-400" : "font-semibold text-emerald-400"}>
            {usingDefaultCredentials ? "You are still using the default demo login" : "Custom login is active"}
          </p>
          <p className="text-sm text-neutral-400">
            {usingDefaultCredentials
              ? "Anyone with the demo credentials can access this dashboard. Set your own email and password below to secure it."
              : `Signed in as ${adminEmail}. Only someone with your current password can change these details.`}
          </p>
        </div>
      </div>

      <form
        onSubmit={handleSubmit}
        className="flex flex-col gap-5 rounded-xl border border-white/10 bg-neutral-950 p-6"
      >
        <div>
          <h2 className="text-base font-semibold text-white">Update login credentials</h2>
          <p className="text-sm text-neutral-400">
            Change the email and password used to sign in to this dashboard. Leave the password fields blank to keep
            your current password.
          </p>
        </div>

        <div className="flex flex-col gap-1.5">
          <Label htmlFor="current-password" className="text-neutral-300">
            Current password
          </Label>
          <Input
            id="current-password"
            type="password"
            required
            autoComplete="current-password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            className="border-white/10 bg-neutral-900 text-white"
            placeholder="Enter your current password"
          />
        </div>

        <div className="flex flex-col gap-1.5">
          <Label htmlFor="new-email" className="text-neutral-300">
            Email
          </Label>
          <Input
            id="new-email"
            type="email"
            required
            autoComplete="email"
            value={newEmail}
            onChange={(e) => setNewEmail(e.target.value)}
            className="border-white/10 bg-neutral-900 text-white"
            placeholder="you@example.com"
          />
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="new-password" className="text-neutral-300">
              New password
            </Label>
            <Input
              id="new-password"
              type="password"
              autoComplete="new-password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="border-white/10 bg-neutral-900 text-white"
              placeholder="Leave blank to keep current"
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="confirm-password" className="text-neutral-300">
              Confirm new password
            </Label>
            <Input
              id="confirm-password"
              type="password"
              autoComplete="new-password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="border-white/10 bg-neutral-900 text-white"
              placeholder="Re-enter new password"
            />
          </div>
        </div>

        {error ? (
          <p role="alert" className="text-sm text-red-400">
            {error}
          </p>
        ) : null}
        {success ? <p className="text-sm text-emerald-400">Credentials updated successfully.</p> : null}

        <Button type="submit" className="w-fit bg-amber-500 text-black hover:bg-amber-400">
          Save credentials
        </Button>
      </form>

      <div className="rounded-xl border border-white/10 bg-neutral-950 p-6 text-sm text-neutral-400">
        <p className="font-medium text-neutral-300">A note on security</p>
        <p className="mt-1">
          Your password is hashed before being saved to this browser&apos;s local storage — it is never stored as
          plain text. Since there is no backend database yet, credentials only apply on this browser/device. Connect
          a database to enable secure sign-in across devices.
        </p>
      </div>
    </div>
  )
}
