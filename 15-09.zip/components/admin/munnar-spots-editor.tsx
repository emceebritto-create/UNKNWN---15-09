"use client"

import { useState } from "react"
import { useTravelData } from "@/contexts/travel-data-context"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { ImageUploadField } from "@/components/admin/image-upload-field"
import { ChevronDown, ChevronUp, Check, Plus, Trash2 } from "lucide-react"
import type { MunnarSpot } from "@/lib/types"

function emptySpot(): MunnarSpot {
  return { name: "New Spot", description: "", type: "", image: "" }
}

export function MunnarSpotsEditor() {
  const { munnarSpots, updateMunnarSpot, addMunnarSpot, deleteMunnarSpot } = useTravelData()
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0)
  const [savedIndex, setSavedIndex] = useState<number | null>(null)

  return (
    <div className="flex max-w-3xl flex-col gap-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-neutral-400">{munnarSpots.length} highlight spots listed on the site</p>
        <Button
          size="sm"
          onClick={() => {
            addMunnarSpot(emptySpot())
            setExpandedIndex(munnarSpots.length)
          }}
          className="bg-amber-500 text-black hover:bg-amber-400"
        >
          <Plus className="size-4" aria-hidden="true" /> Add Spot
        </Button>
      </div>

      {munnarSpots.map((spot, index) => (
        <SpotRow
          key={index}
          spot={spot}
          isExpanded={expandedIndex === index}
          isSaved={savedIndex === index}
          onToggle={() => setExpandedIndex(expandedIndex === index ? null : index)}
          onSave={(updated) => {
            updateMunnarSpot(index, updated)
            setSavedIndex(index)
            setTimeout(() => setSavedIndex(null), 2000)
          }}
          onDelete={() => deleteMunnarSpot(index)}
        />
      ))}
    </div>
  )
}

function SpotRow({
  spot,
  isExpanded,
  isSaved,
  onToggle,
  onSave,
  onDelete,
}: {
  spot: MunnarSpot
  isExpanded: boolean
  isSaved: boolean
  onToggle: () => void
  onSave: (spot: MunnarSpot) => void
  onDelete: () => void
}) {
  const [form, setForm] = useState<MunnarSpot>(spot)

  const set = <K extends keyof MunnarSpot>(key: K, value: MunnarSpot[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  return (
    <div className="rounded-xl border border-white/10 bg-neutral-950">
      <button onClick={onToggle} className="flex w-full items-center justify-between gap-3 p-4 text-left">
        <div>
          <span className="font-semibold text-white">{form.name}</span>
          <span className="ml-2 text-sm text-neutral-500">{form.type}</span>
        </div>
        {isExpanded ? <ChevronUp className="size-4 text-neutral-400" /> : <ChevronDown className="size-4 text-neutral-400" />}
      </button>

      {isExpanded ? (
        <div className="flex flex-col gap-4 border-t border-white/10 p-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex flex-col gap-1.5">
              <Label className="text-neutral-300">Name</Label>
              <Input value={form.name} onChange={(e) => set("name", e.target.value)} className="border-white/10 bg-neutral-900 text-white" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-neutral-300">Type / Category</Label>
              <Input value={form.type} onChange={(e) => set("type", e.target.value)} className="border-white/10 bg-neutral-900 text-white" />
            </div>
            <div className="sm:col-span-2">
              <Label className="text-neutral-300">Description</Label>
              <Textarea
                value={form.description}
                onChange={(e) => set("description", e.target.value)}
                className="mt-1.5 min-h-20 border-white/10 bg-neutral-900 text-white"
              />
            </div>
            <div className="sm:col-span-2">
              <ImageUploadField label="Spot Photo" value={form.image} onChange={(v) => set("image", v)} />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button onClick={() => onSave(form)} size="sm" className="bg-amber-500 text-black hover:bg-amber-400">
              Save
            </Button>
            {isSaved ? (
              <span className="flex items-center gap-1.5 text-sm text-emerald-400">
                <Check className="size-4" aria-hidden="true" /> Saved
              </span>
            ) : null}
            <Button onClick={onDelete} size="sm" variant="outline" className="ml-auto border-red-500/30 text-red-400 hover:bg-red-500/10">
              <Trash2 className="size-4" aria-hidden="true" /> Delete
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  )
}
