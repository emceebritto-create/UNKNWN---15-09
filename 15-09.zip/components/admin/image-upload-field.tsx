"use client"

import { useRef, useState, type ChangeEvent } from "react"
import Image from "next/image"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { fileToDataUrl } from "@/lib/storage"
import { ImageUp, Loader2 } from "lucide-react"

interface ImageUploadFieldProps {
  label: string
  value: string
  onChange: (dataUrl: string) => void
  id?: string
}

export function ImageUploadField({ label, value, onChange, id }: ImageUploadFieldProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [isLoading, setIsLoading] = useState(false)
  const fieldId = id ?? label.toLowerCase().replace(/\s+/g, "-")

  const handleFileChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setIsLoading(true)
    try {
      const dataUrl = await fileToDataUrl(file)
      onChange(dataUrl)
    } finally {
      setIsLoading(false)
      e.target.value = ""
    }
  }

  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={fieldId} className="text-neutral-300">
        {label}
      </Label>
      <div className="flex items-center gap-3">
        <div className="relative size-16 shrink-0 overflow-hidden rounded-lg border border-white/10 bg-neutral-900">
          {value ? (
            <Image src={value || "/placeholder.svg"} alt="" fill className="object-cover" unoptimized />
          ) : (
            <div className="flex size-full items-center justify-center text-neutral-600">
              <ImageUp className="size-5" aria-hidden="true" />
            </div>
          )}
        </div>
        <input
          ref={inputRef}
          id={fieldId}
          type="file"
          accept="image/*"
          className="sr-only"
          onChange={handleFileChange}
        />
        <Button
          type="button"
          variant="outline"
          size="sm"
          disabled={isLoading}
          onClick={() => inputRef.current?.click()}
          className="border-white/10 bg-neutral-900 text-white hover:bg-neutral-800"
        >
          {isLoading ? (
            <Loader2 className="size-4 animate-spin" aria-hidden="true" />
          ) : (
            <ImageUp className="size-4" aria-hidden="true" />
          )}
          {isLoading ? "Uploading…" : "Upload photo"}
        </Button>
      </div>
    </div>
  )
}
