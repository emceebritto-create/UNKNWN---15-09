"use client"

import { useState } from "react"
import { useTravelData } from "@/contexts/travel-data-context"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { ImageUploadField } from "@/components/admin/image-upload-field"
import { Check } from "lucide-react"
import type { BrandInfo } from "@/lib/types"

function Field({
  id,
  label,
  value,
  onChange,
  textarea,
}: {
  id: string
  label: string
  value: string
  onChange: (v: string) => void
  textarea?: boolean
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={id} className="text-neutral-300">
        {label}
      </Label>
      {textarea ? (
        <Textarea
          id={id}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="min-h-20 border-white/10 bg-neutral-900 text-white"
        />
      ) : (
        <Input id={id} value={value} onChange={(e) => onChange(e.target.value)} className="border-white/10 bg-neutral-900 text-white" />
      )}
    </div>
  )
}

export function BrandEditor() {
  const { brandInfo, updateBrandInfo } = useTravelData()
  const [form, setForm] = useState<BrandInfo>(brandInfo)
  const [saved, setSaved] = useState(false)

  const set = <K extends keyof BrandInfo>(key: K, value: BrandInfo[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }))
    setSaved(false)
  }

  const handleSave = () => {
    updateBrandInfo(form)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div className="flex max-w-3xl flex-col gap-8">
      <section className="rounded-xl border border-white/10 bg-neutral-950 p-6">
        <h2 className="mb-4 text-base font-semibold text-white">Brand Identity</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field id="name" label="Brand Name" value={form.name} onChange={(v) => set("name", v)} />
          <Field id="tagline" label="Tagline" value={form.tagline} onChange={(v) => set("tagline", v)} />
          <Field id="conceptTagline" label="Concept Tagline" value={form.conceptTagline} onChange={(v) => set("conceptTagline", v)} />
          <Field id="topBannerText" label="Top Banner Text" value={form.topBannerText} onChange={(v) => set("topBannerText", v)} />
        </div>
      </section>

      <section className="rounded-xl border border-white/10 bg-neutral-950 p-6">
        <h2 className="mb-4 text-base font-semibold text-white">Contact Details</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field id="phone" label="Phone (raw digits)" value={form.phone} onChange={(v) => set("phone", v)} />
          <Field id="phoneDisplay" label="Phone (display)" value={form.phoneDisplay} onChange={(v) => set("phoneDisplay", v)} />
          <Field id="whatsapp" label="WhatsApp Link" value={form.whatsapp} onChange={(v) => set("whatsapp", v)} />
          <Field id="email" label="Email" value={form.email} onChange={(v) => set("email", v)} />
          <div className="sm:col-span-2">
            <Field id="location" label="Office Location" value={form.location} onChange={(v) => set("location", v)} />
          </div>
        </div>
      </section>

      <section className="rounded-xl border border-white/10 bg-neutral-950 p-6">
        <h2 className="mb-4 text-base font-semibold text-white">Hero Section</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field id="heroHeadlineLine1" label="Headline Line 1" value={form.heroHeadlineLine1} onChange={(v) => set("heroHeadlineLine1", v)} />
          <Field id="heroHeadlineAccent" label="Headline Accent Word" value={form.heroHeadlineAccent} onChange={(v) => set("heroHeadlineAccent", v)} />
          <Field id="heroHeadlineLine2" label="Headline Line 2" value={form.heroHeadlineLine2} onChange={(v) => set("heroHeadlineLine2", v)} />
          <Field id="heroHeadlineEnding" label="Headline Ending Word" value={form.heroHeadlineEnding} onChange={(v) => set("heroHeadlineEnding", v)} />
          <div className="sm:col-span-2">
            <Field id="heroSubtitle" label="Hero Subtitle" value={form.heroSubtitle} onChange={(v) => set("heroSubtitle", v)} textarea />
          </div>
          <div className="sm:col-span-2">
            <ImageUploadField label="Hero Background Image" value={form.heroImage} onChange={(v) => set("heroImage", v)} />
          </div>
        </div>
      </section>

      <div className="flex items-center gap-3">
        <Button onClick={handleSave} className="bg-amber-500 text-black hover:bg-amber-400">
          Save Changes
        </Button>
        {saved ? (
          <span className="flex items-center gap-1.5 text-sm text-emerald-400">
            <Check className="size-4" aria-hidden="true" /> Saved
          </span>
        ) : null}
      </div>
    </div>
  )
}
