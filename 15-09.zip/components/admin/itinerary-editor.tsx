"use client"

import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { ListEditor } from "@/components/admin/list-editor"
import { Plus, Trash2 } from "lucide-react"
import type { StrangerTrip } from "@/lib/types"

type ItineraryDay = StrangerTrip["itinerary"][number]

interface ItineraryEditorProps {
  days: ItineraryDay[]
  onChange: (days: ItineraryDay[]) => void
}

/** Editable list of itinerary days, each with a title and its own highlights list. */
export function ItineraryEditor({ days, onChange }: ItineraryEditorProps) {
  const updateDay = (index: number, patch: Partial<ItineraryDay>) => {
    onChange(days.map((d, i) => (i === index ? { ...d, ...patch } : d)))
  }

  const removeDay = (index: number) => {
    onChange(days.filter((_, i) => i !== index))
  }

  const addDay = () => {
    onChange([...days, { day: `Day ${days.length + 1}`, title: "", highlights: [] }])
  }

  return (
    <div className="flex flex-col gap-1.5">
      <Label className="text-neutral-300">Itinerary</Label>
      <div className="flex flex-col gap-3">
        {days.map((day, index) => (
          <div key={index} className="rounded-lg border border-white/10 bg-neutral-900 p-3">
            <div className="mb-3 flex items-center gap-2">
              <Input
                value={day.day}
                onChange={(e) => updateDay(index, { day: e.target.value })}
                className="w-28 border-white/10 bg-neutral-950 text-white"
                placeholder="Day 1"
              />
              <Input
                value={day.title}
                onChange={(e) => updateDay(index, { title: e.target.value })}
                className="flex-1 border-white/10 bg-neutral-950 text-white"
                placeholder="Day title"
              />
              <Button
                variant="outline"
                size="icon"
                onClick={() => removeDay(index)}
                aria-label={`Remove ${day.day}`}
                className="shrink-0 border-red-500/30 text-red-400 hover:bg-red-500/10"
              >
                <Trash2 className="size-4" aria-hidden="true" />
              </Button>
            </div>
            <ListEditor
              label="Highlights"
              items={day.highlights}
              onChange={(highlights) => updateDay(index, { highlights })}
              placeholder="Add a highlight"
            />
          </div>
        ))}
        <Button
          type="button"
          variant="outline"
          onClick={addDay}
          className="self-start border-white/10 bg-neutral-900 text-white hover:bg-neutral-800"
        >
          <Plus className="size-4" aria-hidden="true" /> Add Day
        </Button>
      </div>
    </div>
  )
}
