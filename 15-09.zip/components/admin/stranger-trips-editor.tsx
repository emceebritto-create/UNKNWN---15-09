"use client"

import { useState } from "react"
import { useTravelData } from "@/contexts/travel-data-context"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ImageUploadField } from "@/components/admin/image-upload-field"
import { ListEditor } from "@/components/admin/list-editor"
import { ItineraryEditor } from "@/components/admin/itinerary-editor"
import { Check, ChevronDown, ChevronUp, Plus, Trash2 } from "lucide-react"
import type { StrangerTrip } from "@/lib/types"

const CATEGORIES: StrangerTrip["category"][] = ["Weekend Special", "Adventure Trek", "Camp & Offroad", "Monsoon & Mist"]
const STATUSES: StrangerTrip["status"][] = ["Open", "Filling Fast", "Few Left", "Completed"]

function emptyTrip(): StrangerTrip {
  return {
    id: `trip-${Date.now()}`,
    title: "New Stranger Trip",
    tagline: "",
    dates: "",
    duration: "",
    startingPrice: 0,
    pickupLocations: [],
    groupSize: "",
    remainingSlots: 0,
    status: "Open",
    image: "",
    category: "Weekend Special",
    activities: [],
    itinerary: [],
    included: [],
    notIncluded: [],
  }
}

export function StrangerTripsEditor() {
  const { strangerTrips, updateStrangerTrip, addStrangerTrip, deleteStrangerTrip } = useTravelData()
  const [expandedId, setExpandedId] = useState<string | null>(strangerTrips[0]?.id ?? null)
  const [savedId, setSavedId] = useState<string | null>(null)

  return (
    <div className="flex max-w-3xl flex-col gap-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-neutral-400">{strangerTrips.length} trips listed on the site</p>
        <Button
          size="sm"
          onClick={() => {
            const trip = emptyTrip()
            addStrangerTrip(trip)
            setExpandedId(trip.id)
          }}
          className="bg-amber-500 text-black hover:bg-amber-400"
        >
          <Plus className="size-4" aria-hidden="true" /> Add Trip
        </Button>
      </div>

      {strangerTrips.map((trip) => (
        <TripRow
          key={trip.id}
          trip={trip}
          isExpanded={expandedId === trip.id}
          isSaved={savedId === trip.id}
          onToggle={() => setExpandedId(expandedId === trip.id ? null : trip.id)}
          onSave={(updated) => {
            updateStrangerTrip(updated)
            setSavedId(updated.id)
            setTimeout(() => setSavedId(null), 2000)
          }}
          onDelete={() => deleteStrangerTrip(trip.id)}
        />
      ))}
    </div>
  )
}

function TripRow({
  trip,
  isExpanded,
  isSaved,
  onToggle,
  onSave,
  onDelete,
}: {
  trip: StrangerTrip
  isExpanded: boolean
  isSaved: boolean
  onToggle: () => void
  onSave: (trip: StrangerTrip) => void
  onDelete: () => void
}) {
  const [form, setForm] = useState<StrangerTrip>(trip)

  const set = <K extends keyof StrangerTrip>(key: K, value: StrangerTrip[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  return (
    <div className="rounded-xl border border-white/10 bg-neutral-950">
      <button onClick={onToggle} className="flex w-full items-center justify-between gap-3 p-4 text-left">
        <div className="flex items-center gap-3">
          <span className="font-semibold text-white">{form.title}</span>
          <Badge variant="outline" className="border-white/20 text-neutral-400">
            {form.status}
          </Badge>
        </div>
        {isExpanded ? <ChevronUp className="size-4 text-neutral-400" /> : <ChevronDown className="size-4 text-neutral-400" />}
      </button>

      {isExpanded ? (
        <div className="flex flex-col gap-5 border-t border-white/10 p-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex flex-col gap-1.5">
              <Label className="text-neutral-300">Title</Label>
              <Input value={form.title} onChange={(e) => set("title", e.target.value)} className="border-white/10 bg-neutral-900 text-white" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-neutral-300">Tagline</Label>
              <Input value={form.tagline} onChange={(e) => set("tagline", e.target.value)} className="border-white/10 bg-neutral-900 text-white" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-neutral-300">Dates</Label>
              <Input value={form.dates} onChange={(e) => set("dates", e.target.value)} className="border-white/10 bg-neutral-900 text-white" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-neutral-300">Duration</Label>
              <Input value={form.duration} onChange={(e) => set("duration", e.target.value)} className="border-white/10 bg-neutral-900 text-white" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-neutral-300">Starting Price (₹)</Label>
              <Input
                type="number"
                value={form.startingPrice}
                onChange={(e) => set("startingPrice", Number(e.target.value))}
                className="border-white/10 bg-neutral-900 text-white"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-neutral-300">Original Price (₹, optional)</Label>
              <Input
                type="number"
                value={form.originalPrice ?? ""}
                onChange={(e) => set("originalPrice", e.target.value ? Number(e.target.value) : undefined)}
                className="border-white/10 bg-neutral-900 text-white"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-neutral-300">Group Size</Label>
              <Input value={form.groupSize} onChange={(e) => set("groupSize", e.target.value)} className="border-white/10 bg-neutral-900 text-white" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-neutral-300">Remaining Slots</Label>
              <Input
                type="number"
                value={form.remainingSlots}
                onChange={(e) => set("remainingSlots", Number(e.target.value))}
                className="border-white/10 bg-neutral-900 text-white"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-neutral-300">Status</Label>
              <select
                value={form.status}
                onChange={(e) => set("status", e.target.value as StrangerTrip["status"])}
                className="rounded-md border border-white/10 bg-neutral-900 px-3 py-2 text-sm text-white"
              >
                {STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-neutral-300">Category</Label>
              <select
                value={form.category}
                onChange={(e) => set("category", e.target.value as StrangerTrip["category"])}
                className="rounded-md border border-white/10 bg-neutral-900 px-3 py-2 text-sm text-white"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <div className="sm:col-span-2">
              <ImageUploadField label="Trip Photo" value={form.image} onChange={(v) => set("image", v)} />
            </div>
          </div>

          <ListEditor
            label="Pickup Locations"
            items={form.pickupLocations}
            onChange={(items) => set("pickupLocations", items)}
            placeholder="Add a pickup location"
          />
          <ListEditor label="Activities" items={form.activities} onChange={(items) => set("activities", items)} placeholder="Add an activity" />
          <ItineraryEditor days={form.itinerary} onChange={(days) => set("itinerary", days)} />
          <ListEditor label="Included" items={form.included} onChange={(items) => set("included", items)} placeholder="Add what's included" />
          <ListEditor
            label="Not Included"
            items={form.notIncluded}
            onChange={(items) => set("notIncluded", items)}
            placeholder="Add what's not included"
          />

          <div className="flex items-center gap-3">
            <Button onClick={() => onSave(form)} size="sm" className="bg-amber-500 text-black hover:bg-amber-400">
              Save
            </Button>
            {isSaved ? (
              <span className="flex items-center gap-1.5 text-sm text-emerald-400">
                <Check className="size-4" aria-hidden="true" /> Saved
              </span>
            ) : null}
            <Button onClick={onDelete} size="sm" variant="outline" className="ml-auto border-red-500/30 text-red-400 hover:bg-red-500/10">
              <Trash2 className="size-4" aria-hidden="true" /> Delete
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  )
}
