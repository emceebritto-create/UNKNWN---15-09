"use client"

import { useState, type KeyboardEvent } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Plus, X } from "lucide-react"

interface ListEditorProps {
  label: string
  items: string[]
  onChange: (items: string[]) => void
  placeholder?: string
}

/** Editable list of plain-text entries (features, activities, inclusions, etc). */
export function ListEditor({ label, items, onChange, placeholder }: ListEditorProps) {
  const [draft, setDraft] = useState("")

  const addItem = () => {
    const trimmed = draft.trim()
    if (!trimmed) return
    onChange([...items, trimmed])
    setDraft("")
  }

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.nativeEvent.isComposing) {
      e.preventDefault()
      addItem()
    }
  }

  const removeItem = (index: number) => {
    onChange(items.filter((_, i) => i !== index))
  }

  const updateItem = (index: number, value: string) => {
    onChange(items.map((item, i) => (i === index ? value : item)))
  }

  return (
    <div className="flex flex-col gap-1.5">
      <Label className="text-neutral-300">{label}</Label>
      <div className="flex flex-col gap-2">
        {items.map((item, index) => (
          <div key={index} className="flex items-center gap-2">
            <Input
              value={item}
              onChange={(e) => updateItem(index, e.target.value)}
              className="border-white/10 bg-neutral-900 text-white"
            />
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={() => removeItem(index)}
              aria-label={`Remove item ${index + 1}`}
              className="shrink-0 border-white/10 bg-neutral-900 text-neutral-400 hover:bg-neutral-800 hover:text-white"
            >
              <X className="size-4" aria-hidden="true" />
            </Button>
          </div>
        ))}
        <div className="flex items-center gap-2">
          <Input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={placeholder ?? "Add an item"}
            className="border-white/10 bg-neutral-900 text-white placeholder:text-neutral-500"
          />
          <Button
            type="button"
            variant="outline"
            size="icon"
            onClick={addItem}
            aria-label="Add item"
            className="shrink-0 border-white/10 bg-neutral-900 text-neutral-400 hover:bg-neutral-800 hover:text-white"
          >
            <Plus className="size-4" aria-hidden="true" />
          </Button>
        </div>
      </div>
    </div>
  )
}
