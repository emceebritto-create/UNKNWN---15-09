"use client"

import { useState } from "react"
import { useTravelData } from "@/contexts/travel-data-context"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { ListEditor } from "@/components/admin/list-editor"
import { Check, Plus, Trash2 } from "lucide-react"
import type { DmcData } from "@/lib/types"

function Field({
  id,
  label,
  value,
  onChange,
  textarea,
}: {
  id: string
  label: string
  value: string
  onChange: (v: string) => void
  textarea?: boolean
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={id} className="text-neutral-300">
        {label}
      </Label>
      {textarea ? (
        <Textarea
          id={id}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="min-h-20 border-white/10 bg-neutral-900 text-white"
        />
      ) : (
        <Input id={id} value={value} onChange={(e) => onChange(e.target.value)} className="border-white/10 bg-neutral-900 text-white" />
      )}
    </div>
  )
}

export function DmcEditor() {
  const { dmcData, updateDmcData } = useTravelData()
  const [form, setForm] = useState<DmcData>(dmcData)
  const [saved, setSaved] = useState(false)

  const set = <K extends keyof DmcData>(key: K, value: DmcData[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }))
    setSaved(false)
  }

  const updateServiceEntry = (index: number, field: "title" | "description", value: string) => {
    set(
      "services",
      form.services.map((s, i) => (i === index ? { ...s, [field]: value } : s)),
    )
  }

  const removeServiceEntry = (index: number) => {
    set("services", form.services.filter((_, i) => i !== index))
  }

  const addServiceEntry = () => {
    set("services", [...form.services, { title: "New Service", description: "" }])
  }

  const handleSave = () => {
    updateDmcData(form)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div className="flex max-w-3xl flex-col gap-8">
      <section className="rounded-xl border border-white/10 bg-neutral-950 p-6">
        <h2 className="mb-4 text-base font-semibold text-white">DMC Overview</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field id="badge" label="Badge Text" value={form.badge} onChange={(v) => set("badge", v)} />
          <Field id="headline" label="Headline" value={form.headline} onChange={(v) => set("headline", v)} />
          <Field id="highlightWord" label="Highlight Phrase" value={form.highlightWord} onChange={(v) => set("highlightWord", v)} />
          <Field id="officeLocation" label="Office Location" value={form.officeLocation} onChange={(v) => set("officeLocation", v)} />
          <Field id="phone" label="Phone" value={form.phone} onChange={(v) => set("phone", v)} />
          <Field id="email" label="Email" value={form.email} onChange={(v) => set("email", v)} />
          <div className="sm:col-span-2">
            <Field id="subheadline" label="Subheadline" value={form.subheadline} onChange={(v) => set("subheadline", v)} textarea />
          </div>
          <div className="sm:col-span-2">
            <Field id="description" label="Description" value={form.description} onChange={(v) => set("description", v)} textarea />
          </div>
        </div>
      </section>

      <section className="rounded-xl border border-white/10 bg-neutral-950 p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-base font-semibold text-white">B2B Services Offered</h2>
          <Button size="sm" variant="outline" onClick={addServiceEntry} className="border-white/10 bg-neutral-900 text-white hover:bg-neutral-800">
            <Plus className="size-4" aria-hidden="true" /> Add Service
          </Button>
        </div>
        <div className="flex flex-col gap-3">
          {form.services.map((s, index) => (
            <div key={index} className="flex flex-col gap-2 rounded-lg border border-white/10 bg-neutral-900 p-3 sm:flex-row sm:items-start">
              <div className="flex flex-1 flex-col gap-2">
                <Input
                  value={s.title}
                  onChange={(e) => updateServiceEntry(index, "title", e.target.value)}
                  className="border-white/10 bg-neutral-950 text-white"
                  placeholder="Service title"
                />
                <Textarea
                  value={s.description}
                  onChange={(e) => updateServiceEntry(index, "description", e.target.value)}
                  className="min-h-16 border-white/10 bg-neutral-950 text-white"
                  placeholder="Service description"
                />
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={() => removeServiceEntry(index)}
                aria-label={`Remove ${s.title}`}
                className="shrink-0 border-red-500/30 text-red-400 hover:bg-red-500/10"
              >
                <Trash2 className="size-4" aria-hidden="true" />
              </Button>
            </div>
          ))}
        </div>
      </section>

      <section className="rounded-xl border border-white/10 bg-neutral-950 p-6">
        <h2 className="mb-4 text-base font-semibold text-white">Target Audience</h2>
        <ListEditor label="Audience Types" items={form.targetAudience} onChange={(items) => set("targetAudience", items)} placeholder="Add audience type" />
      </section>

      <div className="flex items-center gap-3">
        <Button onClick={handleSave} className="bg-amber-500 text-black hover:bg-amber-400">
          Save Changes
        </Button>
        {saved ? (
          <span className="flex items-center gap-1.5 text-sm text-emerald-400">
            <Check className="size-4" aria-hidden="true" /> Saved
          </span>
        ) : null}
      </div>
    </div>
  )
}
