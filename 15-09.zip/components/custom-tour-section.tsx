"use client"

import { useState } from "react"
import { Compass, Home, Car, CheckCircle2, MessageCircle, ShieldCheck, Send } from "lucide-react"
import { ACCOMMODATION_OPTIONS, TRANSPORTATION_OPTIONS, MUNNAR_EXPERIENCES } from "@/lib/travel-data"
import { useTravelData } from "@/contexts/travel-data-context"
import type { AccommodationType, TransportationType, MunnarExperience } from "@/lib/types"
import { ScrollFadeSection } from "@/components/scroll-fade-section"

export function CustomTourSection() {
  const { brandInfo, addInquiry } = useTravelData()
  const [days, setDays] = useState<string>("3 Days")
  const [customDays, setCustomDays] = useState<string>("")
  const [travellers, setTravellers] = useState<number>(2)
  const [accommodation, setAccommodation] = useState<AccommodationType>("Cottage")
  const [transportation, setTransportation] = useState<TransportationType>("Jeep")
  const [selectedExperiences, setSelectedExperiences] = useState<MunnarExperience[]>(["Tea plantation visits", "Jeep experiences", "Trekking"])
  const [budget, setBudget] = useState<string>("₹10,000 - ₹20,000")
  const [travelDate, setTravelDate] = useState<string>("")
  const [name, setName] = useState<string>("")
  const [phone, setPhone] = useState<string>("")
  const [email, setEmail] = useState<string>("")
  const [requirements, setRequirements] = useState<string>("")
  const [submitted, setSubmitted] = useState<boolean>(false)

  const dayOptions = ["1 Day", "2 Days", "3 Days", "4 Days", "5 Days", "Custom duration"]

  const toggleExperience = (exp: MunnarExperience) => {
    setSelectedExperiences((prev) => (prev.includes(exp) ? prev.filter((e) => e !== exp) : [...prev, exp]))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!name || !phone) {
      alert("Please provide your name and contact phone number.")
      return
    }

    const finalDays = days === "Custom duration" ? `${customDays || "Custom"} Days` : days
    addInquiry({
      type: "custom_tour",
      title: `Private Custom Tour (${finalDays} • ${travellers} Pax)`,
      customerName: name,
      phone,
      email,
      details: {
        days: finalDays,
        travellers,
        travelDate: travelDate || "Flexible",
        stay: accommodation,
        transportation,
        experiences: selectedExperiences,
        budget,
        notes: requirements || "No additional notes",
      },
    })

    setSubmitted(true)
  }

  const constructWhatsAppEnquiry = () => {
    const finalDays = days === "Custom duration" ? `${customDays || "Custom"} Days` : days
    const expList = selectedExperiences.join(", ") || "General Sightseeing"
    const cleanPhone = brandInfo.phone.replace(/[^0-9]/g, "")
    const text = encodeURIComponent(
      `Hello ${brandInfo.name}! I would like to plan a Private Custom Munnar Tour.\n\n` +
        `• Days: ${finalDays}\n` +
        `• Travellers: ${travellers}\n` +
        `• Travel Date: ${travelDate || "Flexible"}\n` +
        `• Stay: ${accommodation}\n` +
        `• Transportation: ${transportation}\n` +
        `• Experiences: ${expList}\n` +
        `• Approx Budget: ${budget}\n` +
        `• Name: ${name || "Traveller"}\n` +
        `• Notes: ${requirements || "None"}\n\nPlease share a customized itinerary and quote!`,
    )
    return `https://wa.me/${cleanPhone}?text=${text}`
  }

  return (
    <ScrollFadeSection>
      <section id="custom-tours" className="py-20 sm:py-28 bg-white text-black relative border-b-2 border-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-14 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-black text-yellow-400 text-xs font-black uppercase tracking-wider">
              <Compass className="w-3.5 h-3.5" />
              <span>AREA 2 • PRIVATE & CUSTOM TOURS</span>
            </div>

            <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black uppercase tracking-tight text-black">
              YOUR MUNNAR. <span className="bg-yellow-400 px-2 py-0.5 inline-block">YOUR WAY.</span>
            </h2>

            <p className="text-base sm:text-lg text-neutral-700 font-semibold leading-relaxed">
              Planning a private trip? Choose your days, stay, transportation and experiences. We&apos;ll help you create a Munnar journey that fits your
              plans.
            </p>

            <div className="inline-flex items-center gap-3 p-2 px-4 rounded-full bg-neutral-100 border border-neutral-300 text-xs font-bold text-neutral-800">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span>Completely Private • 100% Customized for Couples, Families & Private Circles</span>
            </div>
          </div>

          <div className="bg-neutral-50 rounded-2xl border-2 border-black p-6 sm:p-10 shadow-2xl">
            {submitted ? (
              <div className="text-center py-12 px-4 max-w-2xl mx-auto space-y-6">
                <div className="w-20 h-20 bg-yellow-400 text-black rounded-full flex items-center justify-center mx-auto border-4 border-black">
                  <CheckCircle2 className="w-10 h-10 stroke-[2.5]" />
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-black uppercase tracking-widest bg-black text-yellow-400 px-3 py-1 rounded inline-block">
                    ENQUIRY SUBMITTED SUCCESSFULLY
                  </span>
                  <h3 className="text-3xl sm:text-4xl font-black uppercase text-black">Thank You, {name || "Traveller"}!</h3>
                  <p className="text-neutral-700 text-sm sm:text-base font-medium">
                    Your custom Munnar tour requirements have been logged with our local Munnar team. We will review your selections and contact you at{" "}
                    <strong className="text-black font-extrabold">{phone}</strong> within 30 minutes with a personalized itinerary and clear quotation.
                  </p>
                </div>

                <div className="bg-white p-5 rounded-xl border border-neutral-300 text-left text-xs sm:text-sm font-semibold space-y-2">
                  <div className="text-xs font-black uppercase text-neutral-500 border-b pb-1">Enquiry Summary</div>
                  <div className="grid grid-cols-2 gap-2 text-neutral-800">
                    <div>
                      • Duration: <span className="font-extrabold text-black">{days === "Custom duration" ? `${customDays} Days` : days}</span>
                    </div>
                    <div>
                      • Travellers: <span className="font-extrabold text-black">{travellers} Person(s)</span>
                    </div>
                    <div>
                      • Stay Style: <span className="font-extrabold text-black">{accommodation}</span>
                    </div>
                    <div>
                      • Transportation: <span className="font-extrabold text-black">{transportation}</span>
                    </div>
                    <div className="col-span-2">
                      • Experiences: <span className="font-extrabold text-black">{selectedExperiences.join(", ") || "Custom Sightseeing"}</span>
                    </div>
                    <div>
                      • Target Date: <span className="font-extrabold text-black">{travelDate || "Flexible"}</span>
                    </div>
                    <div>
                      • Budget: <span className="font-extrabold text-black">{budget}</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
                  <a
                    href={constructWhatsAppEnquiry()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-6 py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 shadow-lg transition-colors"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Send Directly on WhatsApp</span>
                  </a>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="px-6 py-4 bg-black text-white hover:bg-neutral-800 font-black text-xs uppercase tracking-wider rounded-lg transition-colors"
                  >
                    Edit Itinerary Details
                  </button>
                </div>

                <div className="text-xs text-neutral-500 font-semibold">
                  Direct phone helpline:{" "}
                  <a href={`tel:${brandInfo.phone}`} className="underline font-bold text-black">
                    {brandInfo.phoneDisplay}
                  </a>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-10">
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-yellow-400 text-black font-black text-xs flex items-center justify-center">1</span>
                    <label className="text-base sm:text-lg font-black uppercase tracking-tight text-black">Select Number of Days</label>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
                    {dayOptions.map((opt) => (
                      <button
                        type="button"
                        key={opt}
                        onClick={() => setDays(opt)}
                        className={`py-3 px-3 rounded-lg text-xs sm:text-sm font-black uppercase tracking-wider border-2 transition-all cursor-pointer ${
                          days === opt ? "bg-black text-yellow-400 border-black shadow-md" : "bg-white text-neutral-800 border-neutral-300 hover:border-black"
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>

                  {days === "Custom duration" && (
                    <div className="pt-2 max-w-xs">
                      <label className="block text-xs font-bold text-neutral-600 mb-1">Specify number of days:</label>
                      <input
                        type="text"
                        placeholder="e.g. 6 Days / 7 Nights"
                        value={customDays}
                        onChange={(e) => setCustomDays(e.target.value)}
                        className="w-full px-3 py-2 border-2 border-black rounded bg-white text-black font-bold text-sm"
                      />
                    </div>
                  )}
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-yellow-400 text-black font-black text-xs flex items-center justify-center">2</span>
                    <label className="text-base sm:text-lg font-black uppercase tracking-tight text-black">Select Number of Travellers</label>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                    {[1, 2, 3, 4, 5, 6, 8, 10, 15].map((num) => (
                      <button
                        type="button"
                        key={num}
                        onClick={() => setTravellers(num)}
                        className={`px-4 py-2.5 rounded-lg text-xs sm:text-sm font-black border-2 transition-all cursor-pointer ${
                          travellers === num ? "bg-black text-yellow-400 border-black shadow" : "bg-white text-neutral-800 border-neutral-300 hover:border-black"
                        }`}
                      >
                        {num} {num === 1 ? "Person" : "People"}
                      </button>
                    ))}
                    <div className="flex items-center gap-2 pl-2">
                      <span className="text-xs font-bold text-neutral-600">Custom count:</span>
                      <input
                        type="number"
                        min={1}
                        max={150}
                        value={travellers}
                        onChange={(e) => setTravellers(Number.parseInt(e.target.value) || 1)}
                        className="w-16 px-2 py-1.5 border-2 border-black rounded bg-white text-black font-black text-sm text-center"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-yellow-400 text-black font-black text-xs flex items-center justify-center">3</span>
                    <label className="text-base sm:text-lg font-black uppercase tracking-tight text-black">Choose Accommodation Preference</label>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {ACCOMMODATION_OPTIONS.map((acc) => (
                      <button
                        type="button"
                        key={acc}
                        onClick={() => setAccommodation(acc)}
                        className={`p-3 rounded-lg text-xs font-bold text-left border-2 transition-all flex flex-col justify-between cursor-pointer ${
                          accommodation === acc ? "bg-black text-yellow-400 border-black shadow" : "bg-white text-neutral-800 border-neutral-300 hover:border-black"
                        }`}
                      >
                        <Home className="w-4 h-4 mb-1.5" />
                        <span className="font-extrabold uppercase">{acc}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-yellow-400 text-black font-black text-xs flex items-center justify-center">4</span>
                    <label className="text-base sm:text-lg font-black uppercase tracking-tight text-black">Choose Transportation</label>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
                    {TRANSPORTATION_OPTIONS.map((trans) => (
                      <button
                        type="button"
                        key={trans}
                        onClick={() => setTransportation(trans)}
                        className={`p-3 rounded-lg text-xs font-bold text-left border-2 transition-all flex flex-col justify-between cursor-pointer ${
                          transportation === trans
                            ? "bg-black text-yellow-400 border-black shadow"
                            : "bg-white text-neutral-800 border-neutral-300 hover:border-black"
                        }`}
                      >
                        <Car className="w-4 h-4 mb-1.5" />
                        <span className="font-extrabold uppercase">{trans}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-yellow-400 text-black font-black text-xs flex items-center justify-center">5</span>
                      <label className="text-base sm:text-lg font-black uppercase tracking-tight text-black">Select Experiences & Activities</label>
                    </div>
                    <span className="text-xs font-bold text-neutral-500">({selectedExperiences.length} selected)</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
                    {MUNNAR_EXPERIENCES.map((exp) => {
                      const isSelected = selectedExperiences.includes(exp.name)
                      return (
                        <button
                          type="button"
                          key={exp.name}
                          onClick={() => toggleExperience(exp.name)}
                          className={`p-3 rounded-lg text-left border-2 transition-all cursor-pointer ${
                            isSelected ? "bg-yellow-400 text-black border-black shadow" : "bg-white text-neutral-800 border-neutral-300 hover:border-black"
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-black uppercase tracking-tight leading-snug">{exp.name}</span>
                            <span
                              className={`w-3.5 h-3.5 rounded-sm border border-black flex items-center justify-center ${
                                isSelected ? "bg-black text-yellow-400" : "bg-white"
                              }`}
                            >
                              {isSelected && <span className="text-[10px] font-black leading-none">✓</span>}
                            </span>
                          </div>
                          <p className="text-[10px] text-neutral-600 line-clamp-1">{exp.description}</p>
                        </button>
                      )
                    })}
                  </div>
                </div>

                <div className="pt-6 border-t-2 border-neutral-200 space-y-6">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-yellow-400 text-black font-black text-xs flex items-center justify-center">6</span>
                    <h3 className="text-base sm:text-lg font-black uppercase tracking-tight text-black">Dates, Budget & Contact Details</h3>
                  </div>

                  <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider text-black mb-1">Preferred Travel Date *</label>
                      <input
                        type="date"
                        value={travelDate}
                        onChange={(e) => setTravelDate(e.target.value)}
                        className="w-full px-3 py-2.5 border-2 border-black rounded-lg bg-white text-black font-bold text-sm focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider text-black mb-1">Approximate Budget (Total or Per Person)</label>
                      <select
                        value={budget}
                        onChange={(e) => setBudget(e.target.value)}
                        className="w-full px-3 py-2.5 border-2 border-black rounded-lg bg-white text-black font-bold text-sm focus:outline-none focus:ring-2 focus:ring-yellow-400"
                      >
                        <option value="Under ₹10,000">Under ₹10,000</option>
                        <option value="₹10,000 - ₹20,000">₹10,000 - ₹20,000</option>
                        <option value="₹20,000 - ₹35,000">₹20,000 - ₹35,000</option>
                        <option value="₹35,000 - ₹50,000">₹35,000 - ₹50,000</option>
                        <option value="Above ₹50,000 (Luxury / Group)">Above ₹50,000 (Luxury / Group)</option>
                        <option value="Flexible / Suggest Best Value">Flexible / Suggest Best Value</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider text-black mb-1">Your Full Name *</label>
                      <input
                        type="text"
                        placeholder="e.g. Rahul Sharma"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full px-3 py-2.5 border-2 border-black rounded-lg bg-white text-black font-bold text-sm focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider text-black mb-1">Contact Phone Number (WhatsApp) *</label>
                      <input
                        type="tel"
                        placeholder="e.g. 9876543210"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full px-3 py-2.5 border-2 border-black rounded-lg bg-white text-black font-bold text-sm focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider text-black mb-1">Email Address (Optional)</label>
                      <input
                        type="email"
                        placeholder="name@domain.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-3 py-2.5 border-2 border-black rounded-lg bg-white text-black font-bold text-sm focus:outline-none focus:ring-2 focus:ring-yellow-400"
                      />
                    </div>

                    <div className="sm:col-span-2 lg:col-span-3">
                      <label className="block text-xs font-black uppercase tracking-wider text-black mb-1">Additional Requirements & Special Requests</label>
                      <textarea
                        rows={2}
                        placeholder="Tell us if you need campfire, honeymoon room decoration, senior citizen friendly vehicle, specific pickup points..."
                        value={requirements}
                        onChange={(e) => setRequirements(e.target.value)}
                        className="w-full px-3 py-2.5 border-2 border-black rounded-lg bg-white text-black font-semibold text-sm focus:outline-none focus:ring-2 focus:ring-yellow-400"
                      />
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-neutral-200">
                    <div className="flex items-center gap-2 text-xs font-bold text-neutral-600">
                      <ShieldCheck className="w-4 h-4 text-black" />
                      <span>Direct Munnar operator quotation • Zero middlemen markup • Phone: {brandInfo.phoneDisplay}</span>
                    </div>

                    <div className="flex items-center gap-3 w-full sm:w-auto">
                      <button
                        type="submit"
                        className="w-full sm:w-auto px-8 py-4 bg-black hover:bg-neutral-900 text-yellow-400 font-black text-sm uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-2 shadow-xl cursor-pointer"
                      >
                        <Send className="w-4 h-4 text-yellow-400" />
                        <span>Submit Custom Tour Enquiry</span>
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            )}
          </div>
        </div>
      </section>
    </ScrollFadeSection>
  )
}
